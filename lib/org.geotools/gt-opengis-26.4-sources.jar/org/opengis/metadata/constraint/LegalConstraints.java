/*
 *    GeoTools - The Open Source Java GIS Toolkit
 *    http://geotools.org
 *
 *    (C) 2011, Open Source Geospatial Foundation (OSGeo)
 *    (C) 2004-2005, Open Geospatial Consortium Inc.
 *
 *    All Rights Reserved. http://www.opengis.org/legal/
 */
package org.opengis.metadata.constraint;

import static org.opengis.annotation.Obligation.CONDITIONAL;
import static org.opengis.annotation.Obligation.OPTIONAL;
import static org.opengis.annotation.Specification.ISO_19115;

import java.util.Collection;
import org.opengis.annotation.UML;
import org.opengis.util.InternationalString;

/**
 * Restrictions and legal prerequisites for accessing and using the resource.
 *
 * @version <A HREF="http://www.opengeospatial.org/standards/as#01-111">ISO 19115</A>
 * @author Martin Desruisseaux (IRD)
 * @author Cory Horner (Refractions Research)
 * @since GeoAPI 2.0
 */
@UML(identifier = "MD_LegalConstraints", specification = ISO_19115)
public interface LegalConstraints extends Constraints {
    /**
     * Access constraints applied to assure the protection of privacy or intellectual property, and
     * any special restrictions or limitations on obtaining the resource.
     *
     * @return Access constraints applied to assure the protection of privacy or intellectual
     *     property.
     */
    @UML(identifier = "accessConstraints", obligation = OPTIONAL, specification = ISO_19115)
    Collection<Restriction> getAccessConstraints();

    /**
     * Constraints applied to assure the protection of privacy or intellectual property, and any
     * special restrictions or limitations or warnings on using the resource.
     *
     * @return Constraints applied to assure the protection of privacy or intellectual property.
     */
    @UML(identifier = "useConstraints", obligation = OPTIONAL, specification = ISO_19115)
    Collection<Restriction> getUseConstraints();

    /**
     * Other restrictions and legal prerequisites for accessing and using the resource. This method
     * should returns a non-empty value only if {@linkplain #getAccessConstraints access
     * constraints} or {@linkplain #getUseConstraints use constraints} declares {@linkplain
     * Restriction#OTHER_RESTRICTIONS other restrictions}.
     *
     * @return Other restrictions and legal prerequisites for accessing and using the resource.
     */
    @UML(identifier = "otherConstraints", obligation = CONDITIONAL, specification = ISO_19115)
    Collection<? extends InternationalString> getOtherConstraints();
}
