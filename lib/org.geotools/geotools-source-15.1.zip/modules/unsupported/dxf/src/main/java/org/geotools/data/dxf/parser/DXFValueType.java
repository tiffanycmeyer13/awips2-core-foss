/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.geotools.data.dxf.parser;

/**
 *
 * @author Chris
 *
 *
 *
 * @source $URL$
 */
public enum DXFValueType {
    STRING,
    SHORT,
    INTEGER,
    LONG,
    BOOLEAN,
    DOUBLE,
    HANDLEHEX,
    IDHEX,
    BINHEX
}
