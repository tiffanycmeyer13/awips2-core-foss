/*
 *    GeoTools - The Open Source Java GIS Toolkit
 *    http://geotools.org
 *
 *    (C) 2011, Open Source Geospatial Foundation (OSGeo)
 *    (C) 2005, Open Geospatial Consortium Inc.
 *
 *    All Rights Reserved. http://www.opengis.org/legal/
 */
package org.geotools.api.filter.identity;

/**
 * ObjectId refered to by Filter 1.1 specification (as an example).
 *
 * <p>Although ObjectId is refered to as an example we are making explicit use of it here in order to show
 * identification being defined with a long (as with several popular object relational mappers).
 *
 * @version <A HREF="http://portal.opengeospatial.org/files/?artifact_id=5929">Implementation specification 1.1</A>
 * @author Jody Garnett, Refractions Research Inc.
 * @since GeoAPI 2.1
 */
public interface ObjectId extends Identifier {

    /** The identifier value, which is a Long. */
    @Override
    Long getID();

    /**
     * Evaluates the identifer value against the given Object.
     *
     * @param obj Object to be tested.
     * @return <code>true</code> if a match, otherwise <code>false</code>
     */
    @Override
    boolean matches(Object obj);
}
