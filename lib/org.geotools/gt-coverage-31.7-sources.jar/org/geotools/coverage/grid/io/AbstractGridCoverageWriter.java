/*
 *    GeoTools - The Open Source Java GIS Toolkit
 *    http://geotools.org
 *
 *    (C) 2005-2008, Open Source Geospatial Foundation (OSGeo)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 */
package org.geotools.coverage.grid.io;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.stream.ImageOutputStream;
import org.geotools.api.coverage.grid.GridCoverageWriter;
import org.geotools.util.factory.GeoTools;
import org.geotools.util.factory.Hints;
import org.geotools.util.logging.Logging;

/**
 * An {@link AbstractGridCoverageWriter} is the base class for all {@link GridCoverageWriter} implementations in
 * GeoTools toolkit.
 *
 * <p>We expect it to become the place where to move functionalities common to all {@link GridCoverageWriter}.
 *
 * @author Simone Giannecchini
 * @since 2.3.x
 */
public abstract class AbstractGridCoverageWriter implements GridCoverageWriter {

    /** The {@link Logger} for this {@link AbstractGridCoverageWriter}. */
    private static final Logger LOGGER = Logging.getLogger(AbstractGridCoverageWriter.class);

    /** the destination object where we will do the writing */
    protected Object destination;

    /** Hints to be used for the writing process. */
    protected Hints hints = GeoTools.getDefaultHints();

    /** The destination {@link ImageOutputStream}. */
    protected ImageOutputStream outStream = null;

    /** Default constructor for an {@link AbstractGridCoverageWriter}. */
    public AbstractGridCoverageWriter() {}

    /** Releases resources held by this {@link AbstractGridCoverageWriter}. */
    @Override
    @SuppressWarnings("PMD.UseTryWithResources")
    public void dispose() {
        if (LOGGER.isLoggable(Level.FINE)) LOGGER.fine("Disposing writer:" + destination);

        if (outStream != null) {
            try {
                outStream.flush();

            } catch (IOException e) {

            } finally {
                try {
                    outStream.close();
                } catch (Throwable e) {

                }
                outStream = null;
                destination = null;
            }
        }
    }

    /**
     * (non-Javadoc)
     *
     * @see org.geotools.api.coverage.grid.GridCoverageWriter#getDestination()
     */
    @Override
    public Object getDestination() {
        return destination;
    }

    /**
     * Implementation of getMetadataNames. Currently unimplemented because it has not been specified where to retrieve
     * the metadata
     *
     * @return null
     * @see org.geotools.api.coverage.grid.GridCoverageWriter#getMetadataNames()
     */
    @Override
    public String[] getMetadataNames() {
        throw new UnsupportedOperationException("Unsupported method");
    }

    /** @see org.geotools.api.coverage.grid.GridCoverageWriter#setCurrentSubname(java.lang.String) */
    @Override
    public void setCurrentSubname(String name) throws IOException {
        throw new UnsupportedOperationException("Unsupported method");
    }

    /** @see org.geotools.api.coverage.grid.GridCoverageWriter#setMetadataValue(java.lang.String, java.lang.String) */
    @Override
    public void setMetadataValue(String name, String value) throws IOException {
        throw new UnsupportedOperationException("Unsupported method");
    }

    /**
     * Forcing the disposal of this {@link AbstractGridCoverageWriter} which may keep a reference to an open
     * {@link ImageOutputStream}
     */
    @Override
    @SuppressWarnings("deprecation") // finalize is deprecated in Java 9
    protected void finalize() throws Throwable {
        dispose();
        super.finalize();
    }
}
