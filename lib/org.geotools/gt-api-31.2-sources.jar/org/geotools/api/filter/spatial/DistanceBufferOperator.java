/*
 *    GeoTools - The Open Source Java GIS Toolkit
 *    http://geotools.org
 *
 *    (C) 2011, Open Source Geospatial Foundation (OSGeo)
 *    (C) 2005, Open Geospatial Consortium Inc.
 *
 *    All Rights Reserved. http://www.opengis.org/legal/
 */
package org.geotools.api.filter.spatial;

// Annotations

/**
 * Abstract superclass for spatial operators that check that one shape satisfies some relation to a
 * buffer around another shape. This could be used to find, for example, all the geometries that
 * come within 10 meters of a river.
 *
 * @version <A
 *     HREF="https://cite.opengeospatial.org/teamengine/about/wfs/1.0.0/site/OGCTestData/wfs/1.0.0/specs/filter/1.0.0/02-059.html">Implementation
 *     specification 1.0</A>
 * @author Chris Dillard (SYS Technologies)
 * @since GeoAPI 2.0
 */
public interface DistanceBufferOperator extends BinarySpatialOperator {
    /**
     * Returns the buffer distance around the geometry that will be used when comparing features'
     * geometries.
     */
    double getDistance();

    /**
     * Gets the units of measure that can be used to interpret the distance value held by this
     * object. An implementation may throw an exception if these units differ from the units of the
     * coordinate system of its geometry or the feature's geometry.
     */
    String getDistanceUnits();
}
