/*
 *    GeoTools - The Open Source Java GIS Toolkit
 *    http://geotools.org
 *
 *    (C) 2008, Open Source Geospatial Foundation (OSGeo)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 */
/**
 * {@linkplain org.geotools.metadata.iso.citation.CitationImpl Citation} implementation. An
 * explanation for this package is provided in the {@linkplain org.geotools.api.metadata.citation
 * OpenGIS&reg; javadoc}. The remaining discussion on this page is specific to the Geotools
 * implementation.
 */
package org.geotools.metadata.iso.citation;
