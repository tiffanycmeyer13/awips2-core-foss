Apache Qpid Common

Common generated functionality for Apache Qpid JMS Client and Broker for Java.
See the readme in the client and broker directories.
