Apache Qpid Proton-J
====================

[![Linux Build Status](https://travis-ci.org/apache/qpid-proton-j.svg?branch=master)](https://travis-ci.org/apache/qpid-proton-j)
[![Windows Build Status](https://ci.appveyor.com/api/projects/status/wh587qrxa3c22mh2/branch/master?svg=true)](https://ci.appveyor.com/project/ApacheSoftwareFoundation/qpid-proton-j/branch/master)


Qpid Proton-J is a high-performance, lightweight messaging library. It can be
used in the widest range of messaging applications, including brokers, client
libraries, routers, bridges, proxies, and more.

Please see http://qpid.apache.org/proton for more information.
