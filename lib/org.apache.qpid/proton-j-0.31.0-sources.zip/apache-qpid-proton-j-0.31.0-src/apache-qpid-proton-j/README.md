This module is used to produce the Apache Qpid Proton-J release assemblies.
