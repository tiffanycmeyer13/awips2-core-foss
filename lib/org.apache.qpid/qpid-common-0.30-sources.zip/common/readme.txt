AMQP Common Java API

Common generated functionality for AMQP Java client and broker. See the 
readme in the client and broker directories.
