
package org.ehcache.xml.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;Java class for event-ordering-type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * &lt;pre&gt;
 * &amp;lt;simpleType name="event-ordering-type"&amp;gt;
 *   &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&amp;gt;
 *     &amp;lt;enumeration value="UNORDERED"/&amp;gt;
 *     &amp;lt;enumeration value="ORDERED"/&amp;gt;
 *   &amp;lt;/restriction&amp;gt;
 * &amp;lt;/simpleType&amp;gt;
 * &lt;/pre&gt;
 * 
 */
@XmlType(name = "event-ordering-type")
@XmlEnum
public enum EventOrderingType {

    UNORDERED,
    ORDERED;

    public String value() {
        return name();
    }

    public static EventOrderingType fromValue(String v) {
        return valueOf(v);
    }

}
