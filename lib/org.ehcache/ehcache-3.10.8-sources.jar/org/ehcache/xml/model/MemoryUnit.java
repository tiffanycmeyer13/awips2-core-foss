
package org.ehcache.xml.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;Java class for memory-unit.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * &lt;pre&gt;
 * &amp;lt;simpleType name="memory-unit"&amp;gt;
 *   &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&amp;gt;
 *     &amp;lt;enumeration value="B"/&amp;gt;
 *     &amp;lt;enumeration value="kB"/&amp;gt;
 *     &amp;lt;enumeration value="MB"/&amp;gt;
 *     &amp;lt;enumeration value="GB"/&amp;gt;
 *     &amp;lt;enumeration value="TB"/&amp;gt;
 *     &amp;lt;enumeration value="PB"/&amp;gt;
 *   &amp;lt;/restriction&amp;gt;
 * &amp;lt;/simpleType&amp;gt;
 * &lt;/pre&gt;
 * 
 */
@XmlType(name = "memory-unit")
@XmlEnum
public enum MemoryUnit {

    B("B"),
    @XmlEnumValue("kB")
    K_B("kB"),
    MB("MB"),
    GB("GB"),
    TB("TB"),
    PB("PB");
    private final String value;

    MemoryUnit(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MemoryUnit fromValue(String v) {
        for (MemoryUnit c: MemoryUnit.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
