
package org.ehcache.xml.model;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * &lt;p&gt;Java class for resource-type-with-prop-subst complex type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType name="resource-type-with-prop-subst"&amp;gt;
 *   &amp;lt;simpleContent&amp;gt;
 *     &amp;lt;extension base="&amp;lt;http://www.ehcache.org/v3&amp;gt;propertyOrPositiveInteger"&amp;gt;
 *       &amp;lt;attribute name="unit" type="{http://www.ehcache.org/v3}resource-unit" default="entries" /&amp;gt;
 *     &amp;lt;/extension&amp;gt;
 *   &amp;lt;/simpleContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "resource-type-with-prop-subst", propOrder = {
    "value"
})
public class ResourceTypeWithPropSubst {

    @XmlValue
    @XmlJavaTypeAdapter(Adapter2 .class)
    protected BigInteger value;
    @XmlAttribute(name = "unit")
    protected ResourceUnit unit;

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public BigInteger getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(BigInteger value) {
        this.value = value;
    }

    /**
     * Gets the value of the unit property.
     * 
     * @return
     *     possible object is
     *     {@link ResourceUnit }
     *     
     */
    public ResourceUnit getUnit() {
        if (unit == null) {
            return ResourceUnit.ENTRIES;
        } else {
            return unit;
        }
    }

    /**
     * Sets the value of the unit property.
     * 
     * @param value
     *     allowed object is
     *     {@link ResourceUnit }
     *     
     */
    public void setUnit(ResourceUnit value) {
        this.unit = value;
    }

    public ResourceTypeWithPropSubst withValue(BigInteger value) {
        setValue(value);
        return this;
    }

    public ResourceTypeWithPropSubst withUnit(ResourceUnit value) {
        setUnit(value);
        return this;
    }

}
