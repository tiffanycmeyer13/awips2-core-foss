/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/**
 * {@link java.util.concurrent.Executor Executor}, {@link java.util.concurrent.ExecutorService ExecutorService},
 * and {@link java.util.concurrent.ScheduledExecutorService ScheduledExecutorService} implementations for transparent
 * {@link org.apache.shiro.subject.Subject Subject} association with threads in an asynchronous execution environment.
 * 
 * @see SubjectAwareExecutor
 * @see SubjectAwareExecutorService
 * @see SubjectAwareScheduledExecutorService
 */
package org.apache.shiro.concurrent;