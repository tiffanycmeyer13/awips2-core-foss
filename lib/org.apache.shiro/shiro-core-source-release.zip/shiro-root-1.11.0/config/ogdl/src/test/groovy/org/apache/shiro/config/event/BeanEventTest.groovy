/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.shiro.config.event

import org.junit.Test

import static org.junit.Assert.assertEquals
import static org.junit.Assert.assertSame

/**
 * @since 1.3
 */
class BeanEventTest {

    @Test
    void testDefault() {

        def m = [foo: 'bar'] as Map<String,Object>
        Object o = new Object()
        BeanEvent evt = new MyBeanEvent('baz', o, m)

        assertEquals 'baz', evt.beanName
        assertSame o, evt.bean
        assertSame m, evt.beanContext
    }

    private class MyBeanEvent extends BeanEvent {
        MyBeanEvent(String beanName, Object bean, Map<String, Object> beanContext) {
            super(beanName, bean, beanContext)
        }
    }
}
