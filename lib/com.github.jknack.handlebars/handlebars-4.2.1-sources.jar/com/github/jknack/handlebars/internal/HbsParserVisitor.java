// Generated from com/github/jknack/handlebars/internal/HbsParser.g4 by ANTLR 4.9.2
package com.github.jknack.handlebars.internal;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link HbsParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface HbsParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link HbsParser#template}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTemplate(HbsParser.TemplateContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBody(HbsParser.BodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatement(HbsParser.StatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#escape}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEscape(HbsParser.EscapeContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#text}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitText(HbsParser.TextContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlock(HbsParser.BlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#rawBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRawBlock(HbsParser.RawBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#blockParams}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockParams(HbsParser.BlockParamsContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#sexpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSexpr(HbsParser.SexprContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#elseBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseBlock(HbsParser.ElseBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#elseStmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseStmt(HbsParser.ElseStmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#elseStmtChain}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseStmtChain(HbsParser.ElseStmtChainContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#unless}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnless(HbsParser.UnlessContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#tvar}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTvar(HbsParser.TvarContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#ampvar}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAmpvar(HbsParser.AmpvarContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#var}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVar(HbsParser.VarContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#delimiters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDelimiters(HbsParser.DelimitersContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#partial}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPartial(HbsParser.PartialContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#partialBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPartialBlock(HbsParser.PartialBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code dynamicPath}
	 * labeled alternative in {@link HbsParser#pexpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDynamicPath(HbsParser.DynamicPathContext ctx);
	/**
	 * Visit a parse tree produced by the {@code staticPath}
	 * labeled alternative in {@link HbsParser#pexpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStaticPath(HbsParser.StaticPathContext ctx);
	/**
	 * Visit a parse tree produced by the {@code literalPath}
	 * labeled alternative in {@link HbsParser#pexpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteralPath(HbsParser.LiteralPathContext ctx);
	/**
	 * Visit a parse tree produced by the {@code stringParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringParam(HbsParser.StringParamContext ctx);
	/**
	 * Visit a parse tree produced by the {@code charParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharParam(HbsParser.CharParamContext ctx);
	/**
	 * Visit a parse tree produced by the {@code numberParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumberParam(HbsParser.NumberParamContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolParam(HbsParser.BoolParamContext ctx);
	/**
	 * Visit a parse tree produced by the {@code refParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRefParam(HbsParser.RefParamContext ctx);
	/**
	 * Visit a parse tree produced by the {@code subParamExpr}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubParamExpr(HbsParser.SubParamExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#hash}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHash(HbsParser.HashContext ctx);
	/**
	 * Visit a parse tree produced by {@link HbsParser#comment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComment(HbsParser.CommentContext ctx);
}