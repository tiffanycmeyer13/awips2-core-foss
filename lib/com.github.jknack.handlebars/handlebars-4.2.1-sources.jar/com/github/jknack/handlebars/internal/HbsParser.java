// Generated from com/github/jknack/handlebars/internal/HbsParser.g4 by ANTLR 4.9.2
package com.github.jknack.handlebars.internal;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class HbsParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.9.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		ESC_VAR=1, TEXT=2, COMMENT=3, START_AMP=4, END_RAW_BLOCK=5, START_RAW=6, 
		START_T=7, UNLESS=8, START_PARTIAL_BLOCK=9, START_BLOCK=10, START_DELIM=11, 
		START_PARTIAL=12, END_BLOCK=13, START=14, END_DELIM=15, WS_DELIM=16, DELIM=17, 
		END_RAW=18, END_T=19, END=20, DECORATOR=21, AS=22, PIPE=23, DOUBLE_STRING=24, 
		SINGLE_STRING=25, EQ=26, NUMBER=27, BOOLEAN=28, ELSE=29, QID=30, PATH=31, 
		LP=32, RP=33, WS=34;
	public static final int
		RULE_template = 0, RULE_body = 1, RULE_statement = 2, RULE_escape = 3, 
		RULE_text = 4, RULE_block = 5, RULE_rawBlock = 6, RULE_blockParams = 7, 
		RULE_sexpr = 8, RULE_elseBlock = 9, RULE_elseStmt = 10, RULE_elseStmtChain = 11, 
		RULE_unless = 12, RULE_tvar = 13, RULE_ampvar = 14, RULE_var = 15, RULE_delimiters = 16, 
		RULE_partial = 17, RULE_partialBlock = 18, RULE_pexpr = 19, RULE_param = 20, 
		RULE_hash = 21, RULE_comment = 22;
	private static String[] makeRuleNames() {
		return new String[] {
			"template", "body", "statement", "escape", "text", "block", "rawBlock", 
			"blockParams", "sexpr", "elseBlock", "elseStmt", "elseStmtChain", "unless", 
			"tvar", "ampvar", "var", "delimiters", "partial", "partialBlock", "pexpr", 
			"param", "hash", "comment"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, "'*'", "'as'", 
			"'|'", null, null, "'='", null, null, "'else'", null, null, "'('", "')'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "ESC_VAR", "TEXT", "COMMENT", "START_AMP", "END_RAW_BLOCK", "START_RAW", 
			"START_T", "UNLESS", "START_PARTIAL_BLOCK", "START_BLOCK", "START_DELIM", 
			"START_PARTIAL", "END_BLOCK", "START", "END_DELIM", "WS_DELIM", "DELIM", 
			"END_RAW", "END_T", "END", "DECORATOR", "AS", "PIPE", "DOUBLE_STRING", 
			"SINGLE_STRING", "EQ", "NUMBER", "BOOLEAN", "ELSE", "QID", "PATH", "LP", 
			"RP", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "HbsParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }



	  public String[] tokenNames() {
	    String[] tokenNames = new String[_SYMBOLIC_NAMES.length];
	    for (int i = 0; i < tokenNames.length; i++) {
	      tokenNames[i] = VOCABULARY.getLiteralName(i);
	      if (tokenNames[i] == null) {
	        tokenNames[i] = VOCABULARY.getSymbolicName(i);
	      }

	      if (tokenNames[i] == null) {
	        tokenNames[i] = "<INVALID>";
	      }
	    }
	    return tokenNames;
	  }

	  void setStart(String start) {
	  }

	  void setEnd(String end) {
	  }

	  private String join(List<Token> tokens) {
	    StringBuilder text = new StringBuilder();
	    for(Token token: tokens) {
	      text.append(token.getText());
	    }
	    return text.toString();
	  }

	public HbsParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class TemplateContext extends ParserRuleContext {
		public BodyContext body() {
			return getRuleContext(BodyContext.class,0);
		}
		public TerminalNode EOF() { return getToken(HbsParser.EOF, 0); }
		public TemplateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_template; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterTemplate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitTemplate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitTemplate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TemplateContext template() throws RecognitionException {
		TemplateContext _localctx = new TemplateContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_template);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(46);
			body();
			setState(47);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BodyContext extends ParserRuleContext {
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public BodyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_body; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterBody(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitBody(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitBody(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BodyContext body() throws RecognitionException {
		BodyContext _localctx = new BodyContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_body);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(52);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(49);
					statement();
					}
					} 
				}
				setState(54);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementContext extends ParserRuleContext {
		public TextContext text() {
			return getRuleContext(TextContext.class,0);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public VarContext var() {
			return getRuleContext(VarContext.class,0);
		}
		public TvarContext tvar() {
			return getRuleContext(TvarContext.class,0);
		}
		public AmpvarContext ampvar() {
			return getRuleContext(AmpvarContext.class,0);
		}
		public UnlessContext unless() {
			return getRuleContext(UnlessContext.class,0);
		}
		public PartialContext partial() {
			return getRuleContext(PartialContext.class,0);
		}
		public PartialBlockContext partialBlock() {
			return getRuleContext(PartialBlockContext.class,0);
		}
		public RawBlockContext rawBlock() {
			return getRuleContext(RawBlockContext.class,0);
		}
		public EscapeContext escape() {
			return getRuleContext(EscapeContext.class,0);
		}
		public CommentContext comment() {
			return getRuleContext(CommentContext.class,0);
		}
		public DelimitersContext delimiters() {
			return getRuleContext(DelimitersContext.class,0);
		}
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitStatement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_statement);
		try {
			setState(67);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TEXT:
				enterOuterAlt(_localctx, 1);
				{
				setState(55);
				text();
				}
				break;
			case START_BLOCK:
				enterOuterAlt(_localctx, 2);
				{
				setState(56);
				block();
				}
				break;
			case START:
				enterOuterAlt(_localctx, 3);
				{
				setState(57);
				var();
				}
				break;
			case START_T:
				enterOuterAlt(_localctx, 4);
				{
				setState(58);
				tvar();
				}
				break;
			case START_AMP:
				enterOuterAlt(_localctx, 5);
				{
				setState(59);
				ampvar();
				}
				break;
			case UNLESS:
				enterOuterAlt(_localctx, 6);
				{
				setState(60);
				unless();
				}
				break;
			case START_PARTIAL:
				enterOuterAlt(_localctx, 7);
				{
				setState(61);
				partial();
				}
				break;
			case START_PARTIAL_BLOCK:
				enterOuterAlt(_localctx, 8);
				{
				setState(62);
				partialBlock();
				}
				break;
			case START_RAW:
				enterOuterAlt(_localctx, 9);
				{
				setState(63);
				rawBlock();
				}
				break;
			case ESC_VAR:
				enterOuterAlt(_localctx, 10);
				{
				setState(64);
				escape();
				}
				break;
			case COMMENT:
				enterOuterAlt(_localctx, 11);
				{
				setState(65);
				comment();
				}
				break;
			case START_DELIM:
				enterOuterAlt(_localctx, 12);
				{
				setState(66);
				delimiters();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EscapeContext extends ParserRuleContext {
		public TerminalNode ESC_VAR() { return getToken(HbsParser.ESC_VAR, 0); }
		public EscapeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_escape; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterEscape(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitEscape(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitEscape(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EscapeContext escape() throws RecognitionException {
		EscapeContext _localctx = new EscapeContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_escape);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(69);
			match(ESC_VAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TextContext extends ParserRuleContext {
		public TerminalNode TEXT() { return getToken(HbsParser.TEXT, 0); }
		public TextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_text; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterText(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitText(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitText(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TextContext text() throws RecognitionException {
		TextContext _localctx = new TextContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_text);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(71);
			match(TEXT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BlockContext extends ParserRuleContext {
		public Token startToken;
		public BodyContext thenBody;
		public Token nameEnd;
		public SexprContext sexpr() {
			return getRuleContext(SexprContext.class,0);
		}
		public List<TerminalNode> END() { return getTokens(HbsParser.END); }
		public TerminalNode END(int i) {
			return getToken(HbsParser.END, i);
		}
		public TerminalNode END_BLOCK() { return getToken(HbsParser.END_BLOCK, 0); }
		public TerminalNode START_BLOCK() { return getToken(HbsParser.START_BLOCK, 0); }
		public BodyContext body() {
			return getRuleContext(BodyContext.class,0);
		}
		public TerminalNode QID() { return getToken(HbsParser.QID, 0); }
		public TerminalNode DECORATOR() { return getToken(HbsParser.DECORATOR, 0); }
		public BlockParamsContext blockParams() {
			return getRuleContext(BlockParamsContext.class,0);
		}
		public List<ElseBlockContext> elseBlock() {
			return getRuleContexts(ElseBlockContext.class);
		}
		public ElseBlockContext elseBlock(int i) {
			return getRuleContext(ElseBlockContext.class,i);
		}
		public BlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_block; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockContext block() throws RecognitionException {
		BlockContext _localctx = new BlockContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_block);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(73);
			((BlockContext)_localctx).startToken = match(START_BLOCK);
			setState(75);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DECORATOR) {
				{
				setState(74);
				match(DECORATOR);
				}
			}

			setState(77);
			sexpr();
			setState(79);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(78);
				blockParams();
				}
			}

			setState(81);
			match(END);
			setState(82);
			((BlockContext)_localctx).thenBody = body();
			setState(86);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==UNLESS || _la==START) {
				{
				{
				setState(83);
				elseBlock();
				}
				}
				setState(88);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(89);
			match(END_BLOCK);
			setState(90);
			((BlockContext)_localctx).nameEnd = match(QID);
			setState(91);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RawBlockContext extends ParserRuleContext {
		public Token startToken;
		public BodyContext thenBody;
		public Token nameEnd;
		public SexprContext sexpr() {
			return getRuleContext(SexprContext.class,0);
		}
		public List<TerminalNode> END_RAW() { return getTokens(HbsParser.END_RAW); }
		public TerminalNode END_RAW(int i) {
			return getToken(HbsParser.END_RAW, i);
		}
		public TerminalNode END_RAW_BLOCK() { return getToken(HbsParser.END_RAW_BLOCK, 0); }
		public TerminalNode START_RAW() { return getToken(HbsParser.START_RAW, 0); }
		public BodyContext body() {
			return getRuleContext(BodyContext.class,0);
		}
		public TerminalNode QID() { return getToken(HbsParser.QID, 0); }
		public RawBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rawBlock; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterRawBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitRawBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitRawBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RawBlockContext rawBlock() throws RecognitionException {
		RawBlockContext _localctx = new RawBlockContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_rawBlock);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(93);
			((RawBlockContext)_localctx).startToken = match(START_RAW);
			setState(94);
			sexpr();
			setState(95);
			match(END_RAW);
			setState(96);
			((RawBlockContext)_localctx).thenBody = body();
			setState(97);
			match(END_RAW_BLOCK);
			setState(98);
			((RawBlockContext)_localctx).nameEnd = match(QID);
			setState(99);
			match(END_RAW);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BlockParamsContext extends ParserRuleContext {
		public TerminalNode AS() { return getToken(HbsParser.AS, 0); }
		public List<TerminalNode> PIPE() { return getTokens(HbsParser.PIPE); }
		public TerminalNode PIPE(int i) {
			return getToken(HbsParser.PIPE, i);
		}
		public List<TerminalNode> QID() { return getTokens(HbsParser.QID); }
		public TerminalNode QID(int i) {
			return getToken(HbsParser.QID, i);
		}
		public BlockParamsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockParams; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterBlockParams(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitBlockParams(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitBlockParams(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockParamsContext blockParams() throws RecognitionException {
		BlockParamsContext _localctx = new BlockParamsContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_blockParams);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(101);
			match(AS);
			setState(102);
			match(PIPE);
			setState(104); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(103);
				match(QID);
				}
				}
				setState(106); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==QID );
			setState(108);
			match(PIPE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SexprContext extends ParserRuleContext {
		public TerminalNode QID() { return getToken(HbsParser.QID, 0); }
		public List<ParamContext> param() {
			return getRuleContexts(ParamContext.class);
		}
		public ParamContext param(int i) {
			return getRuleContext(ParamContext.class,i);
		}
		public List<HashContext> hash() {
			return getRuleContexts(HashContext.class);
		}
		public HashContext hash(int i) {
			return getRuleContext(HashContext.class,i);
		}
		public SexprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sexpr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterSexpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitSexpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitSexpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SexprContext sexpr() throws RecognitionException {
		SexprContext _localctx = new SexprContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_sexpr);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(110);
			match(QID);
			setState(114);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(111);
					param();
					}
					} 
				}
				setState(116);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
			}
			setState(120);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==QID) {
				{
				{
				setState(117);
				hash();
				}
				}
				setState(122);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElseBlockContext extends ParserRuleContext {
		public ElseStmtContext elseStmt() {
			return getRuleContext(ElseStmtContext.class,0);
		}
		public ElseStmtChainContext elseStmtChain() {
			return getRuleContext(ElseStmtChainContext.class,0);
		}
		public ElseBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseBlock; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterElseBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitElseBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitElseBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElseBlockContext elseBlock() throws RecognitionException {
		ElseBlockContext _localctx = new ElseBlockContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_elseBlock);
		try {
			setState(125);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(123);
				elseStmt();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(124);
				elseStmtChain();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElseStmtContext extends ParserRuleContext {
		public Token inverseToken;
		public BodyContext unlessBody;
		public TerminalNode END() { return getToken(HbsParser.END, 0); }
		public BodyContext body() {
			return getRuleContext(BodyContext.class,0);
		}
		public TerminalNode START() { return getToken(HbsParser.START, 0); }
		public TerminalNode UNLESS() { return getToken(HbsParser.UNLESS, 0); }
		public TerminalNode ELSE() { return getToken(HbsParser.ELSE, 0); }
		public ElseStmtContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseStmt; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterElseStmt(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitElseStmt(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitElseStmt(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElseStmtContext elseStmt() throws RecognitionException {
		ElseStmtContext _localctx = new ElseStmtContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_elseStmt);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(130);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case UNLESS:
				{
				setState(127);
				((ElseStmtContext)_localctx).inverseToken = match(UNLESS);
				}
				break;
			case START:
				{
				setState(128);
				match(START);
				setState(129);
				((ElseStmtContext)_localctx).inverseToken = match(ELSE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(132);
			match(END);
			setState(133);
			((ElseStmtContext)_localctx).unlessBody = body();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElseStmtChainContext extends ParserRuleContext {
		public Token inverseToken;
		public BodyContext unlessBody;
		public SexprContext sexpr() {
			return getRuleContext(SexprContext.class,0);
		}
		public TerminalNode END() { return getToken(HbsParser.END, 0); }
		public BodyContext body() {
			return getRuleContext(BodyContext.class,0);
		}
		public TerminalNode START() { return getToken(HbsParser.START, 0); }
		public TerminalNode UNLESS() { return getToken(HbsParser.UNLESS, 0); }
		public TerminalNode ELSE() { return getToken(HbsParser.ELSE, 0); }
		public BlockParamsContext blockParams() {
			return getRuleContext(BlockParamsContext.class,0);
		}
		public ElseStmtChainContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseStmtChain; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterElseStmtChain(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitElseStmtChain(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitElseStmtChain(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElseStmtChainContext elseStmtChain() throws RecognitionException {
		ElseStmtChainContext _localctx = new ElseStmtChainContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_elseStmtChain);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(138);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case UNLESS:
				{
				setState(135);
				((ElseStmtChainContext)_localctx).inverseToken = match(UNLESS);
				}
				break;
			case START:
				{
				setState(136);
				match(START);
				setState(137);
				((ElseStmtChainContext)_localctx).inverseToken = match(ELSE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(140);
			sexpr();
			setState(142);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(141);
				blockParams();
				}
			}

			setState(144);
			match(END);
			setState(145);
			((ElseStmtChainContext)_localctx).unlessBody = body();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UnlessContext extends ParserRuleContext {
		public Token nameEnd;
		public TerminalNode UNLESS() { return getToken(HbsParser.UNLESS, 0); }
		public SexprContext sexpr() {
			return getRuleContext(SexprContext.class,0);
		}
		public List<TerminalNode> END() { return getTokens(HbsParser.END); }
		public TerminalNode END(int i) {
			return getToken(HbsParser.END, i);
		}
		public BodyContext body() {
			return getRuleContext(BodyContext.class,0);
		}
		public TerminalNode END_BLOCK() { return getToken(HbsParser.END_BLOCK, 0); }
		public TerminalNode QID() { return getToken(HbsParser.QID, 0); }
		public BlockParamsContext blockParams() {
			return getRuleContext(BlockParamsContext.class,0);
		}
		public UnlessContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unless; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterUnless(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitUnless(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitUnless(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnlessContext unless() throws RecognitionException {
		UnlessContext _localctx = new UnlessContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_unless);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(147);
			match(UNLESS);
			setState(148);
			sexpr();
			setState(150);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(149);
				blockParams();
				}
			}

			setState(152);
			match(END);
			setState(153);
			body();
			setState(154);
			match(END_BLOCK);
			setState(155);
			((UnlessContext)_localctx).nameEnd = match(QID);
			setState(156);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TvarContext extends ParserRuleContext {
		public TerminalNode START_T() { return getToken(HbsParser.START_T, 0); }
		public SexprContext sexpr() {
			return getRuleContext(SexprContext.class,0);
		}
		public TerminalNode END_T() { return getToken(HbsParser.END_T, 0); }
		public TvarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tvar; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterTvar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitTvar(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitTvar(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TvarContext tvar() throws RecognitionException {
		TvarContext _localctx = new TvarContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_tvar);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(158);
			match(START_T);
			setState(159);
			sexpr();
			setState(160);
			match(END_T);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AmpvarContext extends ParserRuleContext {
		public TerminalNode START_AMP() { return getToken(HbsParser.START_AMP, 0); }
		public SexprContext sexpr() {
			return getRuleContext(SexprContext.class,0);
		}
		public TerminalNode END() { return getToken(HbsParser.END, 0); }
		public AmpvarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ampvar; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterAmpvar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitAmpvar(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitAmpvar(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AmpvarContext ampvar() throws RecognitionException {
		AmpvarContext _localctx = new AmpvarContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_ampvar);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(162);
			match(START_AMP);
			setState(163);
			sexpr();
			setState(164);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VarContext extends ParserRuleContext {
		public TerminalNode START() { return getToken(HbsParser.START, 0); }
		public SexprContext sexpr() {
			return getRuleContext(SexprContext.class,0);
		}
		public TerminalNode END() { return getToken(HbsParser.END, 0); }
		public TerminalNode DECORATOR() { return getToken(HbsParser.DECORATOR, 0); }
		public VarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterVar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitVar(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitVar(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VarContext var() throws RecognitionException {
		VarContext _localctx = new VarContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_var);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(166);
			match(START);
			setState(168);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DECORATOR) {
				{
				setState(167);
				match(DECORATOR);
				}
			}

			setState(170);
			sexpr();
			setState(171);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DelimitersContext extends ParserRuleContext {
		public Token DELIM;
		public List<Token> startDelim = new ArrayList<Token>();
		public List<Token> endDelim = new ArrayList<Token>();
		public TerminalNode START_DELIM() { return getToken(HbsParser.START_DELIM, 0); }
		public TerminalNode END_DELIM() { return getToken(HbsParser.END_DELIM, 0); }
		public List<TerminalNode> WS_DELIM() { return getTokens(HbsParser.WS_DELIM); }
		public TerminalNode WS_DELIM(int i) {
			return getToken(HbsParser.WS_DELIM, i);
		}
		public List<TerminalNode> DELIM() { return getTokens(HbsParser.DELIM); }
		public TerminalNode DELIM(int i) {
			return getToken(HbsParser.DELIM, i);
		}
		public DelimitersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_delimiters; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterDelimiters(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitDelimiters(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitDelimiters(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DelimitersContext delimiters() throws RecognitionException {
		DelimitersContext _localctx = new DelimitersContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_delimiters);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(173);
			match(START_DELIM);
			setState(177);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==WS_DELIM) {
				{
				{
				setState(174);
				match(WS_DELIM);
				}
				}
				setState(179);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(181); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(180);
				((DelimitersContext)_localctx).DELIM = match(DELIM);
				((DelimitersContext)_localctx).startDelim.add(((DelimitersContext)_localctx).DELIM);
				}
				}
				setState(183); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==DELIM );
			setStart(join(((DelimitersContext)_localctx).startDelim));
			setState(187); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(186);
				match(WS_DELIM);
				}
				}
				setState(189); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==WS_DELIM );
			setState(192); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(191);
				((DelimitersContext)_localctx).DELIM = match(DELIM);
				((DelimitersContext)_localctx).endDelim.add(((DelimitersContext)_localctx).DELIM);
				}
				}
				setState(194); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==DELIM );
			setState(199);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==WS_DELIM) {
				{
				{
				setState(196);
				match(WS_DELIM);
				}
				}
				setState(201);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(202);
			match(END_DELIM);
			setEnd(join(((DelimitersContext)_localctx).endDelim));
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PartialContext extends ParserRuleContext {
		public TerminalNode START_PARTIAL() { return getToken(HbsParser.START_PARTIAL, 0); }
		public PexprContext pexpr() {
			return getRuleContext(PexprContext.class,0);
		}
		public TerminalNode END() { return getToken(HbsParser.END, 0); }
		public PartialContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_partial; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterPartial(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitPartial(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitPartial(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PartialContext partial() throws RecognitionException {
		PartialContext _localctx = new PartialContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_partial);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(205);
			match(START_PARTIAL);
			setState(206);
			pexpr();
			setState(207);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PartialBlockContext extends ParserRuleContext {
		public BodyContext thenBody;
		public Token nameEnd;
		public TerminalNode START_PARTIAL_BLOCK() { return getToken(HbsParser.START_PARTIAL_BLOCK, 0); }
		public PexprContext pexpr() {
			return getRuleContext(PexprContext.class,0);
		}
		public List<TerminalNode> END() { return getTokens(HbsParser.END); }
		public TerminalNode END(int i) {
			return getToken(HbsParser.END, i);
		}
		public TerminalNode END_BLOCK() { return getToken(HbsParser.END_BLOCK, 0); }
		public BodyContext body() {
			return getRuleContext(BodyContext.class,0);
		}
		public TerminalNode QID() { return getToken(HbsParser.QID, 0); }
		public PartialBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_partialBlock; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterPartialBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitPartialBlock(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitPartialBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PartialBlockContext partialBlock() throws RecognitionException {
		PartialBlockContext _localctx = new PartialBlockContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_partialBlock);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(209);
			match(START_PARTIAL_BLOCK);
			setState(210);
			pexpr();
			setState(211);
			match(END);
			setState(212);
			((PartialBlockContext)_localctx).thenBody = body();
			setState(213);
			match(END_BLOCK);
			setState(214);
			((PartialBlockContext)_localctx).nameEnd = match(QID);
			setState(215);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PexprContext extends ParserRuleContext {
		public PexprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pexpr; }
	 
		public PexprContext() { }
		public void copyFrom(PexprContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class DynamicPathContext extends PexprContext {
		public TerminalNode LP() { return getToken(HbsParser.LP, 0); }
		public SexprContext sexpr() {
			return getRuleContext(SexprContext.class,0);
		}
		public TerminalNode RP() { return getToken(HbsParser.RP, 0); }
		public TerminalNode QID() { return getToken(HbsParser.QID, 0); }
		public List<HashContext> hash() {
			return getRuleContexts(HashContext.class);
		}
		public HashContext hash(int i) {
			return getRuleContext(HashContext.class,i);
		}
		public DynamicPathContext(PexprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterDynamicPath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitDynamicPath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitDynamicPath(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class StaticPathContext extends PexprContext {
		public Token path;
		public List<TerminalNode> QID() { return getTokens(HbsParser.QID); }
		public TerminalNode QID(int i) {
			return getToken(HbsParser.QID, i);
		}
		public TerminalNode PATH() { return getToken(HbsParser.PATH, 0); }
		public List<HashContext> hash() {
			return getRuleContexts(HashContext.class);
		}
		public HashContext hash(int i) {
			return getRuleContext(HashContext.class,i);
		}
		public StaticPathContext(PexprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterStaticPath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitStaticPath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitStaticPath(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class LiteralPathContext extends PexprContext {
		public Token path;
		public TerminalNode DOUBLE_STRING() { return getToken(HbsParser.DOUBLE_STRING, 0); }
		public TerminalNode SINGLE_STRING() { return getToken(HbsParser.SINGLE_STRING, 0); }
		public TerminalNode QID() { return getToken(HbsParser.QID, 0); }
		public List<HashContext> hash() {
			return getRuleContexts(HashContext.class);
		}
		public HashContext hash(int i) {
			return getRuleContext(HashContext.class,i);
		}
		public LiteralPathContext(PexprContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterLiteralPath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitLiteralPath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitLiteralPath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PexprContext pexpr() throws RecognitionException {
		PexprContext _localctx = new PexprContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_pexpr);
		int _la;
		try {
			setState(249);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LP:
				_localctx = new DynamicPathContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(217);
				match(LP);
				setState(218);
				sexpr();
				setState(219);
				match(RP);
				setState(221);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,19,_ctx) ) {
				case 1:
					{
					setState(220);
					match(QID);
					}
					break;
				}
				setState(226);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==QID) {
					{
					{
					setState(223);
					hash();
					}
					}
					setState(228);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case QID:
			case PATH:
				_localctx = new StaticPathContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(229);
				((StaticPathContext)_localctx).path = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==QID || _la==PATH) ) {
					((StaticPathContext)_localctx).path = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(231);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,21,_ctx) ) {
				case 1:
					{
					setState(230);
					match(QID);
					}
					break;
				}
				setState(236);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==QID) {
					{
					{
					setState(233);
					hash();
					}
					}
					setState(238);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case DOUBLE_STRING:
			case SINGLE_STRING:
				_localctx = new LiteralPathContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(239);
				((LiteralPathContext)_localctx).path = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==DOUBLE_STRING || _la==SINGLE_STRING) ) {
					((LiteralPathContext)_localctx).path = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(241);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,23,_ctx) ) {
				case 1:
					{
					setState(240);
					match(QID);
					}
					break;
				}
				setState(246);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==QID) {
					{
					{
					setState(243);
					hash();
					}
					}
					setState(248);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParamContext extends ParserRuleContext {
		public ParamContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_param; }
	 
		public ParamContext() { }
		public void copyFrom(ParamContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class SubParamExprContext extends ParamContext {
		public TerminalNode LP() { return getToken(HbsParser.LP, 0); }
		public SexprContext sexpr() {
			return getRuleContext(SexprContext.class,0);
		}
		public TerminalNode RP() { return getToken(HbsParser.RP, 0); }
		public SubParamExprContext(ParamContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterSubParamExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitSubParamExpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitSubParamExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class StringParamContext extends ParamContext {
		public TerminalNode DOUBLE_STRING() { return getToken(HbsParser.DOUBLE_STRING, 0); }
		public StringParamContext(ParamContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterStringParam(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitStringParam(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitStringParam(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class RefParamContext extends ParamContext {
		public TerminalNode QID() { return getToken(HbsParser.QID, 0); }
		public RefParamContext(ParamContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterRefParam(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitRefParam(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitRefParam(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class NumberParamContext extends ParamContext {
		public TerminalNode NUMBER() { return getToken(HbsParser.NUMBER, 0); }
		public NumberParamContext(ParamContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterNumberParam(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitNumberParam(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitNumberParam(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolParamContext extends ParamContext {
		public TerminalNode BOOLEAN() { return getToken(HbsParser.BOOLEAN, 0); }
		public BoolParamContext(ParamContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterBoolParam(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitBoolParam(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitBoolParam(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CharParamContext extends ParamContext {
		public TerminalNode SINGLE_STRING() { return getToken(HbsParser.SINGLE_STRING, 0); }
		public CharParamContext(ParamContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterCharParam(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitCharParam(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitCharParam(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParamContext param() throws RecognitionException {
		ParamContext _localctx = new ParamContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_param);
		try {
			setState(260);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case DOUBLE_STRING:
				_localctx = new StringParamContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(251);
				match(DOUBLE_STRING);
				}
				break;
			case SINGLE_STRING:
				_localctx = new CharParamContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(252);
				match(SINGLE_STRING);
				}
				break;
			case NUMBER:
				_localctx = new NumberParamContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(253);
				match(NUMBER);
				}
				break;
			case BOOLEAN:
				_localctx = new BoolParamContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(254);
				match(BOOLEAN);
				}
				break;
			case QID:
				_localctx = new RefParamContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(255);
				match(QID);
				}
				break;
			case LP:
				_localctx = new SubParamExprContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(256);
				match(LP);
				setState(257);
				sexpr();
				setState(258);
				match(RP);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class HashContext extends ParserRuleContext {
		public TerminalNode QID() { return getToken(HbsParser.QID, 0); }
		public TerminalNode EQ() { return getToken(HbsParser.EQ, 0); }
		public ParamContext param() {
			return getRuleContext(ParamContext.class,0);
		}
		public HashContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_hash; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterHash(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitHash(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitHash(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HashContext hash() throws RecognitionException {
		HashContext _localctx = new HashContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_hash);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(262);
			match(QID);
			setState(263);
			match(EQ);
			setState(264);
			param();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CommentContext extends ParserRuleContext {
		public TerminalNode COMMENT() { return getToken(HbsParser.COMMENT, 0); }
		public CommentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).enterComment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HbsParserListener ) ((HbsParserListener)listener).exitComment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HbsParserVisitor ) return ((HbsParserVisitor<? extends T>)visitor).visitComment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CommentContext comment() throws RecognitionException {
		CommentContext _localctx = new CommentContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_comment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(266);
			match(COMMENT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3$\u010f\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\3\2\3\2\3"+
		"\2\3\3\7\3\65\n\3\f\3\16\38\13\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3"+
		"\4\3\4\3\4\5\4F\n\4\3\5\3\5\3\6\3\6\3\7\3\7\5\7N\n\7\3\7\3\7\5\7R\n\7"+
		"\3\7\3\7\3\7\7\7W\n\7\f\7\16\7Z\13\7\3\7\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3"+
		"\b\3\b\3\b\3\b\3\t\3\t\3\t\6\tk\n\t\r\t\16\tl\3\t\3\t\3\n\3\n\7\ns\n\n"+
		"\f\n\16\nv\13\n\3\n\7\ny\n\n\f\n\16\n|\13\n\3\13\3\13\5\13\u0080\n\13"+
		"\3\f\3\f\3\f\5\f\u0085\n\f\3\f\3\f\3\f\3\r\3\r\3\r\5\r\u008d\n\r\3\r\3"+
		"\r\5\r\u0091\n\r\3\r\3\r\3\r\3\16\3\16\3\16\5\16\u0099\n\16\3\16\3\16"+
		"\3\16\3\16\3\16\3\16\3\17\3\17\3\17\3\17\3\20\3\20\3\20\3\20\3\21\3\21"+
		"\5\21\u00ab\n\21\3\21\3\21\3\21\3\22\3\22\7\22\u00b2\n\22\f\22\16\22\u00b5"+
		"\13\22\3\22\6\22\u00b8\n\22\r\22\16\22\u00b9\3\22\3\22\6\22\u00be\n\22"+
		"\r\22\16\22\u00bf\3\22\6\22\u00c3\n\22\r\22\16\22\u00c4\3\22\7\22\u00c8"+
		"\n\22\f\22\16\22\u00cb\13\22\3\22\3\22\3\22\3\23\3\23\3\23\3\23\3\24\3"+
		"\24\3\24\3\24\3\24\3\24\3\24\3\24\3\25\3\25\3\25\3\25\5\25\u00e0\n\25"+
		"\3\25\7\25\u00e3\n\25\f\25\16\25\u00e6\13\25\3\25\3\25\5\25\u00ea\n\25"+
		"\3\25\7\25\u00ed\n\25\f\25\16\25\u00f0\13\25\3\25\3\25\5\25\u00f4\n\25"+
		"\3\25\7\25\u00f7\n\25\f\25\16\25\u00fa\13\25\5\25\u00fc\n\25\3\26\3\26"+
		"\3\26\3\26\3\26\3\26\3\26\3\26\3\26\5\26\u0107\n\26\3\27\3\27\3\27\3\27"+
		"\3\30\3\30\3\30\2\2\31\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,"+
		".\2\4\3\2 !\3\2\32\33\2\u0121\2\60\3\2\2\2\4\66\3\2\2\2\6E\3\2\2\2\bG"+
		"\3\2\2\2\nI\3\2\2\2\fK\3\2\2\2\16_\3\2\2\2\20g\3\2\2\2\22p\3\2\2\2\24"+
		"\177\3\2\2\2\26\u0084\3\2\2\2\30\u008c\3\2\2\2\32\u0095\3\2\2\2\34\u00a0"+
		"\3\2\2\2\36\u00a4\3\2\2\2 \u00a8\3\2\2\2\"\u00af\3\2\2\2$\u00cf\3\2\2"+
		"\2&\u00d3\3\2\2\2(\u00fb\3\2\2\2*\u0106\3\2\2\2,\u0108\3\2\2\2.\u010c"+
		"\3\2\2\2\60\61\5\4\3\2\61\62\7\2\2\3\62\3\3\2\2\2\63\65\5\6\4\2\64\63"+
		"\3\2\2\2\658\3\2\2\2\66\64\3\2\2\2\66\67\3\2\2\2\67\5\3\2\2\28\66\3\2"+
		"\2\29F\5\n\6\2:F\5\f\7\2;F\5 \21\2<F\5\34\17\2=F\5\36\20\2>F\5\32\16\2"+
		"?F\5$\23\2@F\5&\24\2AF\5\16\b\2BF\5\b\5\2CF\5.\30\2DF\5\"\22\2E9\3\2\2"+
		"\2E:\3\2\2\2E;\3\2\2\2E<\3\2\2\2E=\3\2\2\2E>\3\2\2\2E?\3\2\2\2E@\3\2\2"+
		"\2EA\3\2\2\2EB\3\2\2\2EC\3\2\2\2ED\3\2\2\2F\7\3\2\2\2GH\7\3\2\2H\t\3\2"+
		"\2\2IJ\7\4\2\2J\13\3\2\2\2KM\7\f\2\2LN\7\27\2\2ML\3\2\2\2MN\3\2\2\2NO"+
		"\3\2\2\2OQ\5\22\n\2PR\5\20\t\2QP\3\2\2\2QR\3\2\2\2RS\3\2\2\2ST\7\26\2"+
		"\2TX\5\4\3\2UW\5\24\13\2VU\3\2\2\2WZ\3\2\2\2XV\3\2\2\2XY\3\2\2\2Y[\3\2"+
		"\2\2ZX\3\2\2\2[\\\7\17\2\2\\]\7 \2\2]^\7\26\2\2^\r\3\2\2\2_`\7\b\2\2`"+
		"a\5\22\n\2ab\7\24\2\2bc\5\4\3\2cd\7\7\2\2de\7 \2\2ef\7\24\2\2f\17\3\2"+
		"\2\2gh\7\30\2\2hj\7\31\2\2ik\7 \2\2ji\3\2\2\2kl\3\2\2\2lj\3\2\2\2lm\3"+
		"\2\2\2mn\3\2\2\2no\7\31\2\2o\21\3\2\2\2pt\7 \2\2qs\5*\26\2rq\3\2\2\2s"+
		"v\3\2\2\2tr\3\2\2\2tu\3\2\2\2uz\3\2\2\2vt\3\2\2\2wy\5,\27\2xw\3\2\2\2"+
		"y|\3\2\2\2zx\3\2\2\2z{\3\2\2\2{\23\3\2\2\2|z\3\2\2\2}\u0080\5\26\f\2~"+
		"\u0080\5\30\r\2\177}\3\2\2\2\177~\3\2\2\2\u0080\25\3\2\2\2\u0081\u0085"+
		"\7\n\2\2\u0082\u0083\7\20\2\2\u0083\u0085\7\37\2\2\u0084\u0081\3\2\2\2"+
		"\u0084\u0082\3\2\2\2\u0085\u0086\3\2\2\2\u0086\u0087\7\26\2\2\u0087\u0088"+
		"\5\4\3\2\u0088\27\3\2\2\2\u0089\u008d\7\n\2\2\u008a\u008b\7\20\2\2\u008b"+
		"\u008d\7\37\2\2\u008c\u0089\3\2\2\2\u008c\u008a\3\2\2\2\u008d\u008e\3"+
		"\2\2\2\u008e\u0090\5\22\n\2\u008f\u0091\5\20\t\2\u0090\u008f\3\2\2\2\u0090"+
		"\u0091\3\2\2\2\u0091\u0092\3\2\2\2\u0092\u0093\7\26\2\2\u0093\u0094\5"+
		"\4\3\2\u0094\31\3\2\2\2\u0095\u0096\7\n\2\2\u0096\u0098\5\22\n\2\u0097"+
		"\u0099\5\20\t\2\u0098\u0097\3\2\2\2\u0098\u0099\3\2\2\2\u0099\u009a\3"+
		"\2\2\2\u009a\u009b\7\26\2\2\u009b\u009c\5\4\3\2\u009c\u009d\7\17\2\2\u009d"+
		"\u009e\7 \2\2\u009e\u009f\7\26\2\2\u009f\33\3\2\2\2\u00a0\u00a1\7\t\2"+
		"\2\u00a1\u00a2\5\22\n\2\u00a2\u00a3\7\25\2\2\u00a3\35\3\2\2\2\u00a4\u00a5"+
		"\7\6\2\2\u00a5\u00a6\5\22\n\2\u00a6\u00a7\7\26\2\2\u00a7\37\3\2\2\2\u00a8"+
		"\u00aa\7\20\2\2\u00a9\u00ab\7\27\2\2\u00aa\u00a9\3\2\2\2\u00aa\u00ab\3"+
		"\2\2\2\u00ab\u00ac\3\2\2\2\u00ac\u00ad\5\22\n\2\u00ad\u00ae\7\26\2\2\u00ae"+
		"!\3\2\2\2\u00af\u00b3\7\r\2\2\u00b0\u00b2\7\22\2\2\u00b1\u00b0\3\2\2\2"+
		"\u00b2\u00b5\3\2\2\2\u00b3\u00b1\3\2\2\2\u00b3\u00b4\3\2\2\2\u00b4\u00b7"+
		"\3\2\2\2\u00b5\u00b3\3\2\2\2\u00b6\u00b8\7\23\2\2\u00b7\u00b6\3\2\2\2"+
		"\u00b8\u00b9\3\2\2\2\u00b9\u00b7\3\2\2\2\u00b9\u00ba\3\2\2\2\u00ba\u00bb"+
		"\3\2\2\2\u00bb\u00bd\b\22\1\2\u00bc\u00be\7\22\2\2\u00bd\u00bc\3\2\2\2"+
		"\u00be\u00bf\3\2\2\2\u00bf\u00bd\3\2\2\2\u00bf\u00c0\3\2\2\2\u00c0\u00c2"+
		"\3\2\2\2\u00c1\u00c3\7\23\2\2\u00c2\u00c1\3\2\2\2\u00c3\u00c4\3\2\2\2"+
		"\u00c4\u00c2\3\2\2\2\u00c4\u00c5\3\2\2\2\u00c5\u00c9\3\2\2\2\u00c6\u00c8"+
		"\7\22\2\2\u00c7\u00c6\3\2\2\2\u00c8\u00cb\3\2\2\2\u00c9\u00c7\3\2\2\2"+
		"\u00c9\u00ca\3\2\2\2\u00ca\u00cc\3\2\2\2\u00cb\u00c9\3\2\2\2\u00cc\u00cd"+
		"\7\21\2\2\u00cd\u00ce\b\22\1\2\u00ce#\3\2\2\2\u00cf\u00d0\7\16\2\2\u00d0"+
		"\u00d1\5(\25\2\u00d1\u00d2\7\26\2\2\u00d2%\3\2\2\2\u00d3\u00d4\7\13\2"+
		"\2\u00d4\u00d5\5(\25\2\u00d5\u00d6\7\26\2\2\u00d6\u00d7\5\4\3\2\u00d7"+
		"\u00d8\7\17\2\2\u00d8\u00d9\7 \2\2\u00d9\u00da\7\26\2\2\u00da\'\3\2\2"+
		"\2\u00db\u00dc\7\"\2\2\u00dc\u00dd\5\22\n\2\u00dd\u00df\7#\2\2\u00de\u00e0"+
		"\7 \2\2\u00df\u00de\3\2\2\2\u00df\u00e0\3\2\2\2\u00e0\u00e4\3\2\2\2\u00e1"+
		"\u00e3\5,\27\2\u00e2\u00e1\3\2\2\2\u00e3\u00e6\3\2\2\2\u00e4\u00e2\3\2"+
		"\2\2\u00e4\u00e5\3\2\2\2\u00e5\u00fc\3\2\2\2\u00e6\u00e4\3\2\2\2\u00e7"+
		"\u00e9\t\2\2\2\u00e8\u00ea\7 \2\2\u00e9\u00e8\3\2\2\2\u00e9\u00ea\3\2"+
		"\2\2\u00ea\u00ee\3\2\2\2\u00eb\u00ed\5,\27\2\u00ec\u00eb\3\2\2\2\u00ed"+
		"\u00f0\3\2\2\2\u00ee\u00ec\3\2\2\2\u00ee\u00ef\3\2\2\2\u00ef\u00fc\3\2"+
		"\2\2\u00f0\u00ee\3\2\2\2\u00f1\u00f3\t\3\2\2\u00f2\u00f4\7 \2\2\u00f3"+
		"\u00f2\3\2\2\2\u00f3\u00f4\3\2\2\2\u00f4\u00f8\3\2\2\2\u00f5\u00f7\5,"+
		"\27\2\u00f6\u00f5\3\2\2\2\u00f7\u00fa\3\2\2\2\u00f8\u00f6\3\2\2\2\u00f8"+
		"\u00f9\3\2\2\2\u00f9\u00fc\3\2\2\2\u00fa\u00f8\3\2\2\2\u00fb\u00db\3\2"+
		"\2\2\u00fb\u00e7\3\2\2\2\u00fb\u00f1\3\2\2\2\u00fc)\3\2\2\2\u00fd\u0107"+
		"\7\32\2\2\u00fe\u0107\7\33\2\2\u00ff\u0107\7\35\2\2\u0100\u0107\7\36\2"+
		"\2\u0101\u0107\7 \2\2\u0102\u0103\7\"\2\2\u0103\u0104\5\22\n\2\u0104\u0105"+
		"\7#\2\2\u0105\u0107\3\2\2\2\u0106\u00fd\3\2\2\2\u0106\u00fe\3\2\2\2\u0106"+
		"\u00ff\3\2\2\2\u0106\u0100\3\2\2\2\u0106\u0101\3\2\2\2\u0106\u0102\3\2"+
		"\2\2\u0107+\3\2\2\2\u0108\u0109\7 \2\2\u0109\u010a\7\34\2\2\u010a\u010b"+
		"\5*\26\2\u010b-\3\2\2\2\u010c\u010d\7\5\2\2\u010d/\3\2\2\2\35\66EMQXl"+
		"tz\177\u0084\u008c\u0090\u0098\u00aa\u00b3\u00b9\u00bf\u00c4\u00c9\u00df"+
		"\u00e4\u00e9\u00ee\u00f3\u00f8\u00fb\u0106";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}