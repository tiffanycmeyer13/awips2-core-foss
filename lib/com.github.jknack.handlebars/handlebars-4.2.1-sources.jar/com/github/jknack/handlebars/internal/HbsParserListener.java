// Generated from com/github/jknack/handlebars/internal/HbsParser.g4 by ANTLR 4.9.2
package com.github.jknack.handlebars.internal;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link HbsParser}.
 */
public interface HbsParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link HbsParser#template}.
	 * @param ctx the parse tree
	 */
	void enterTemplate(HbsParser.TemplateContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#template}.
	 * @param ctx the parse tree
	 */
	void exitTemplate(HbsParser.TemplateContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#body}.
	 * @param ctx the parse tree
	 */
	void enterBody(HbsParser.BodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#body}.
	 * @param ctx the parse tree
	 */
	void exitBody(HbsParser.BodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterStatement(HbsParser.StatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitStatement(HbsParser.StatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#escape}.
	 * @param ctx the parse tree
	 */
	void enterEscape(HbsParser.EscapeContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#escape}.
	 * @param ctx the parse tree
	 */
	void exitEscape(HbsParser.EscapeContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#text}.
	 * @param ctx the parse tree
	 */
	void enterText(HbsParser.TextContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#text}.
	 * @param ctx the parse tree
	 */
	void exitText(HbsParser.TextContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(HbsParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(HbsParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#rawBlock}.
	 * @param ctx the parse tree
	 */
	void enterRawBlock(HbsParser.RawBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#rawBlock}.
	 * @param ctx the parse tree
	 */
	void exitRawBlock(HbsParser.RawBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#blockParams}.
	 * @param ctx the parse tree
	 */
	void enterBlockParams(HbsParser.BlockParamsContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#blockParams}.
	 * @param ctx the parse tree
	 */
	void exitBlockParams(HbsParser.BlockParamsContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#sexpr}.
	 * @param ctx the parse tree
	 */
	void enterSexpr(HbsParser.SexprContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#sexpr}.
	 * @param ctx the parse tree
	 */
	void exitSexpr(HbsParser.SexprContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#elseBlock}.
	 * @param ctx the parse tree
	 */
	void enterElseBlock(HbsParser.ElseBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#elseBlock}.
	 * @param ctx the parse tree
	 */
	void exitElseBlock(HbsParser.ElseBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#elseStmt}.
	 * @param ctx the parse tree
	 */
	void enterElseStmt(HbsParser.ElseStmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#elseStmt}.
	 * @param ctx the parse tree
	 */
	void exitElseStmt(HbsParser.ElseStmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#elseStmtChain}.
	 * @param ctx the parse tree
	 */
	void enterElseStmtChain(HbsParser.ElseStmtChainContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#elseStmtChain}.
	 * @param ctx the parse tree
	 */
	void exitElseStmtChain(HbsParser.ElseStmtChainContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#unless}.
	 * @param ctx the parse tree
	 */
	void enterUnless(HbsParser.UnlessContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#unless}.
	 * @param ctx the parse tree
	 */
	void exitUnless(HbsParser.UnlessContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#tvar}.
	 * @param ctx the parse tree
	 */
	void enterTvar(HbsParser.TvarContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#tvar}.
	 * @param ctx the parse tree
	 */
	void exitTvar(HbsParser.TvarContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#ampvar}.
	 * @param ctx the parse tree
	 */
	void enterAmpvar(HbsParser.AmpvarContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#ampvar}.
	 * @param ctx the parse tree
	 */
	void exitAmpvar(HbsParser.AmpvarContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#var}.
	 * @param ctx the parse tree
	 */
	void enterVar(HbsParser.VarContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#var}.
	 * @param ctx the parse tree
	 */
	void exitVar(HbsParser.VarContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#delimiters}.
	 * @param ctx the parse tree
	 */
	void enterDelimiters(HbsParser.DelimitersContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#delimiters}.
	 * @param ctx the parse tree
	 */
	void exitDelimiters(HbsParser.DelimitersContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#partial}.
	 * @param ctx the parse tree
	 */
	void enterPartial(HbsParser.PartialContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#partial}.
	 * @param ctx the parse tree
	 */
	void exitPartial(HbsParser.PartialContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#partialBlock}.
	 * @param ctx the parse tree
	 */
	void enterPartialBlock(HbsParser.PartialBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#partialBlock}.
	 * @param ctx the parse tree
	 */
	void exitPartialBlock(HbsParser.PartialBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code dynamicPath}
	 * labeled alternative in {@link HbsParser#pexpr}.
	 * @param ctx the parse tree
	 */
	void enterDynamicPath(HbsParser.DynamicPathContext ctx);
	/**
	 * Exit a parse tree produced by the {@code dynamicPath}
	 * labeled alternative in {@link HbsParser#pexpr}.
	 * @param ctx the parse tree
	 */
	void exitDynamicPath(HbsParser.DynamicPathContext ctx);
	/**
	 * Enter a parse tree produced by the {@code staticPath}
	 * labeled alternative in {@link HbsParser#pexpr}.
	 * @param ctx the parse tree
	 */
	void enterStaticPath(HbsParser.StaticPathContext ctx);
	/**
	 * Exit a parse tree produced by the {@code staticPath}
	 * labeled alternative in {@link HbsParser#pexpr}.
	 * @param ctx the parse tree
	 */
	void exitStaticPath(HbsParser.StaticPathContext ctx);
	/**
	 * Enter a parse tree produced by the {@code literalPath}
	 * labeled alternative in {@link HbsParser#pexpr}.
	 * @param ctx the parse tree
	 */
	void enterLiteralPath(HbsParser.LiteralPathContext ctx);
	/**
	 * Exit a parse tree produced by the {@code literalPath}
	 * labeled alternative in {@link HbsParser#pexpr}.
	 * @param ctx the parse tree
	 */
	void exitLiteralPath(HbsParser.LiteralPathContext ctx);
	/**
	 * Enter a parse tree produced by the {@code stringParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void enterStringParam(HbsParser.StringParamContext ctx);
	/**
	 * Exit a parse tree produced by the {@code stringParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void exitStringParam(HbsParser.StringParamContext ctx);
	/**
	 * Enter a parse tree produced by the {@code charParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void enterCharParam(HbsParser.CharParamContext ctx);
	/**
	 * Exit a parse tree produced by the {@code charParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void exitCharParam(HbsParser.CharParamContext ctx);
	/**
	 * Enter a parse tree produced by the {@code numberParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void enterNumberParam(HbsParser.NumberParamContext ctx);
	/**
	 * Exit a parse tree produced by the {@code numberParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void exitNumberParam(HbsParser.NumberParamContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void enterBoolParam(HbsParser.BoolParamContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void exitBoolParam(HbsParser.BoolParamContext ctx);
	/**
	 * Enter a parse tree produced by the {@code refParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void enterRefParam(HbsParser.RefParamContext ctx);
	/**
	 * Exit a parse tree produced by the {@code refParam}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void exitRefParam(HbsParser.RefParamContext ctx);
	/**
	 * Enter a parse tree produced by the {@code subParamExpr}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void enterSubParamExpr(HbsParser.SubParamExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code subParamExpr}
	 * labeled alternative in {@link HbsParser#param}.
	 * @param ctx the parse tree
	 */
	void exitSubParamExpr(HbsParser.SubParamExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#hash}.
	 * @param ctx the parse tree
	 */
	void enterHash(HbsParser.HashContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#hash}.
	 * @param ctx the parse tree
	 */
	void exitHash(HbsParser.HashContext ctx);
	/**
	 * Enter a parse tree produced by {@link HbsParser#comment}.
	 * @param ctx the parse tree
	 */
	void enterComment(HbsParser.CommentContext ctx);
	/**
	 * Exit a parse tree produced by {@link HbsParser#comment}.
	 * @param ctx the parse tree
	 */
	void exitComment(HbsParser.CommentContext ctx);
}