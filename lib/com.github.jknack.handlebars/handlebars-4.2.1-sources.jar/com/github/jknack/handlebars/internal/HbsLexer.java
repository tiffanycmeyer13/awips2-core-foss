// Generated from com/github/jknack/handlebars/internal/HbsLexer.g4 by ANTLR 4.9.2
package com.github.jknack.handlebars.internal;
import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.misc.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class HbsLexer extends Lexer {
	static { RuntimeMetaData.checkVersion("4.9.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		ESC_VAR=1, TEXT=2, COMMENT=3, START_AMP=4, END_RAW_BLOCK=5, START_RAW=6, 
		START_T=7, UNLESS=8, START_PARTIAL_BLOCK=9, START_BLOCK=10, START_DELIM=11, 
		START_PARTIAL=12, END_BLOCK=13, START=14, END_DELIM=15, WS_DELIM=16, DELIM=17, 
		END_RAW=18, END_T=19, END=20, DECORATOR=21, AS=22, PIPE=23, DOUBLE_STRING=24, 
		SINGLE_STRING=25, EQ=26, NUMBER=27, BOOLEAN=28, ELSE=29, QID=30, PATH=31, 
		LP=32, RP=33, WS=34;
	public static final int
		SET_DELIMS=1, VAR=2;
	public static String[] channelNames = {
		"DEFAULT_TOKEN_CHANNEL", "HIDDEN"
	};

	public static String[] modeNames = {
		"DEFAULT_MODE", "SET_DELIMS", "VAR"
	};

	private static String[] makeRuleNames() {
		return new String[] {
			"ESC_VAR", "TEXT", "COMMENT", "START_AMP", "END_RAW_BLOCK", "START_RAW", 
			"START_T", "UNLESS", "START_PARTIAL_BLOCK", "START_BLOCK", "START_DELIM", 
			"START_PARTIAL", "END_BLOCK", "START", "END_DELIM", "WS_DELIM", "DELIM", 
			"END_RAW", "END_T", "END", "DECORATOR", "AS", "PIPE", "DOUBLE_STRING", 
			"SINGLE_STRING", "EQ", "NUMBER", "BOOLEAN", "ELSE", "QID", "PATH", "PATH_SEGMENT", 
			"ID_SEPARATOR", "ID", "ID_START", "ID_SUFFIX", "ID_ESCAPE", "ID_PART", 
			"LP", "RP", "WS"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, "'*'", "'as'", 
			"'|'", null, null, "'='", null, null, "'else'", null, null, "'('", "')'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "ESC_VAR", "TEXT", "COMMENT", "START_AMP", "END_RAW_BLOCK", "START_RAW", 
			"START_T", "UNLESS", "START_PARTIAL_BLOCK", "START_BLOCK", "START_DELIM", 
			"START_PARTIAL", "END_BLOCK", "START", "END_DELIM", "WS_DELIM", "DELIM", 
			"END_RAW", "END_T", "END", "DECORATOR", "AS", "PIPE", "DOUBLE_STRING", 
			"SINGLE_STRING", "EQ", "NUMBER", "BOOLEAN", "ELSE", "QID", "PATH", "LP", 
			"RP", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}



	  // Some default values
	  String start = "{{";

	  String end = "}}";

	  boolean whiteSpaceControl;

	  public HbsLexer(CharStream input, String start, String end) {
	    this(input);
	    this.start = start;
	    this.end = end;
	  }

	  private boolean consumeUntil(final String token) {
	    int tokenOffset = 0;
	    int colOffset = 0;
	    int lineOffset = 0;
	    boolean inNewline = false;
	    boolean resetLine = false;
	    boolean hasNewLine = false;
	    while(!isEOF(tokenOffset) && !(ahead("\\" + token, tokenOffset) || ahead(token, tokenOffset))) {
	      if (resetLine) {
	        hasNewLine = true;
	        colOffset = 0;
	        lineOffset+=1;
	        resetLine = false;
	      }
	      tokenOffset+=1;
	      colOffset+=1;
	      int chr = _input.LA(tokenOffset);
	      if (!inNewline && '\n' == chr) {
	        resetLine = true;
	      }
	      inNewline = false;
	      if ('\r' == chr) {
	        inNewline = true;
	        resetLine = true;
	      }
	    }
	    if (tokenOffset == 0) {
	      return false;
	    }
	    // Since we found the text, increase the CharStream's index.
	    _input.seek(_input.index() + tokenOffset - 1);
	    getInterpreter().setCharPositionInLine(hasNewLine ? (colOffset - 1) : (_tokenStartCharPositionInLine + colOffset - 1));
	    getInterpreter().setLine(_tokenStartLine + lineOffset);
	    return true;
	  }

	  private boolean comment(final String start, final String end) {
	    String commentClose;
	    if (ahead(start + "!--")) {
	      commentClose = "--" + end;
	    } else if (ahead(start + "!")) {
	      commentClose = end;
	    } else {
	      return false;
	    }

	    int offset = 0;
	    while (!isEOF(offset)) {
	      if (ahead(commentClose, offset)) {
	        break;
	      }
	      offset += 1;
	    }
	    offset += commentClose.length();
	    // Since we found the text, increase the CharStream's index.
	    _input.seek(_input.index() + offset - 1);
	    getInterpreter().setCharPositionInLine(_tokenStartCharPositionInLine + offset - 1);
	    return true;
	  }

	  private boolean varEscape(final String start, final String end) {
	    if (ahead("\\" + start)) {
	      int offset = start.length();
	      while (!isEOF(offset)) {
	        if (ahead(end, offset)) {
	          break;
	        }
	        if (ahead(start, offset)) {
	          return false;
	        }
	        offset += 1;
	      }
	      offset += end.length();
	      // Since we found the text, increase the CharStream's index.
	      _input.seek(_input.index() + offset - 1);
	      getInterpreter().setCharPositionInLine(_tokenStartCharPositionInLine + offset - 1);
	      return true;
	    }
	    return false;
	  }

	  private boolean startToken(final String delim) {
	    boolean matches = tryToken(delim + "~");
	    if (matches) {
	      whiteSpaceControl = true;
	    }
	    return matches || tryToken(delim);
	  }

	  private boolean startToken(final String delim, String subtype) {
	    boolean matches = tryToken(delim + subtype);
	    if (!matches) {
	      matches = tryToken(delim + "~" + subtype);
	      if (matches) {
	        whiteSpaceControl = true;
	      }
	    }
	    return matches;
	  }

	  private boolean endToken(final String delim) {
	    return endToken(delim, "");
	  }

	  private boolean endToken(final String delim, String subtype) {
	    boolean matches = tryToken(subtype + delim);
	    if (!matches) {
	      matches = tryToken(subtype + "~" + delim);
	      if (matches) {
	        whiteSpaceControl = true;
	      }
	    }
	    return matches;
	  }

	  private boolean tryToken(final String text) {
	    if (ahead(text)) {
	      // Since we found the text, increase the CharStream's index.
	      _input.seek(_input.index() + text.length() - 1);
	      getInterpreter().setCharPositionInLine(_tokenStartCharPositionInLine + text.length() - 1);
	      return true;
	    }
	    return false;
	  }

	  private boolean isEOF(final int offset) {
	    return _input.LA(offset + 1) == EOF;
	  }

	  private boolean ahead(final String text) {
	    return ahead(text, 0);
	  }

	  private boolean ahead(final String text, int offset) {

	    // See if `text` is ahead in the CharStream.
	    for (int i = 0; i < text.length(); i++) {
	      int ch = _input.LA(i + offset + 1);
	      if (ch != text.charAt(i)) {
	        // Nope, we didn't find `text`.
	        return false;
	      }
	    }

	    return true;
	  }


	public HbsLexer(CharStream input) {
		super(input);
		_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@Override
	public String getGrammarFileName() { return "HbsLexer.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public String[] getChannelNames() { return channelNames; }

	@Override
	public String[] getModeNames() { return modeNames; }

	@Override
	public ATN getATN() { return _ATN; }

	@Override
	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 0:
			return ESC_VAR_sempred((RuleContext)_localctx, predIndex);
		case 1:
			return TEXT_sempred((RuleContext)_localctx, predIndex);
		case 2:
			return COMMENT_sempred((RuleContext)_localctx, predIndex);
		case 3:
			return START_AMP_sempred((RuleContext)_localctx, predIndex);
		case 4:
			return END_RAW_BLOCK_sempred((RuleContext)_localctx, predIndex);
		case 5:
			return START_RAW_sempred((RuleContext)_localctx, predIndex);
		case 6:
			return START_T_sempred((RuleContext)_localctx, predIndex);
		case 7:
			return UNLESS_sempred((RuleContext)_localctx, predIndex);
		case 8:
			return START_PARTIAL_BLOCK_sempred((RuleContext)_localctx, predIndex);
		case 9:
			return START_BLOCK_sempred((RuleContext)_localctx, predIndex);
		case 10:
			return START_DELIM_sempred((RuleContext)_localctx, predIndex);
		case 11:
			return START_PARTIAL_sempred((RuleContext)_localctx, predIndex);
		case 12:
			return END_BLOCK_sempred((RuleContext)_localctx, predIndex);
		case 13:
			return START_sempred((RuleContext)_localctx, predIndex);
		case 14:
			return END_DELIM_sempred((RuleContext)_localctx, predIndex);
		case 17:
			return END_RAW_sempred((RuleContext)_localctx, predIndex);
		case 18:
			return END_T_sempred((RuleContext)_localctx, predIndex);
		case 19:
			return END_sempred((RuleContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean ESC_VAR_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return varEscape(start, end);
		}
		return true;
	}
	private boolean TEXT_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 1:
			return consumeUntil(start);
		}
		return true;
	}
	private boolean COMMENT_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 2:
			return comment(start, end);
		}
		return true;
	}
	private boolean START_AMP_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 3:
			return startToken(start, "&");
		}
		return true;
	}
	private boolean END_RAW_BLOCK_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 4:
			return startToken(start, "{{/");
		}
		return true;
	}
	private boolean START_RAW_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 5:
			return startToken(start, "{{");
		}
		return true;
	}
	private boolean START_T_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 6:
			return startToken(start, "{");
		}
		return true;
	}
	private boolean UNLESS_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 7:
			return startToken(start, "^");
		}
		return true;
	}
	private boolean START_PARTIAL_BLOCK_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 8:
			return startToken(start, "#>");
		}
		return true;
	}
	private boolean START_BLOCK_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 9:
			return startToken(start, "#");
		}
		return true;
	}
	private boolean START_DELIM_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 10:
			return startToken(start, "=");
		}
		return true;
	}
	private boolean START_PARTIAL_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 11:
			return startToken(start, ">");
		}
		return true;
	}
	private boolean END_BLOCK_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 12:
			return startToken(start, "/");
		}
		return true;
	}
	private boolean START_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 13:
			return startToken(start);
		}
		return true;
	}
	private boolean END_DELIM_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 14:
			return endToken("=" + end);
		}
		return true;
	}
	private boolean END_RAW_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 15:
			return endToken(end, "}}");
		}
		return true;
	}
	private boolean END_T_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 16:
			return endToken(end, "}");
		}
		return true;
	}
	private boolean END_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 17:
			return endToken(end);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\2$\u0147\b\1\b\1\b"+
		"\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n"+
		"\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21"+
		"\4\22\t\22\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30"+
		"\4\31\t\31\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37"+
		"\4 \t \4!\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t&\4\'\t\'\4(\t(\4)\t)\4*\t"+
		"*\3\2\3\2\3\2\3\3\3\3\3\3\3\4\3\4\3\4\3\5\3\5\3\5\3\5\3\5\3\6\3\6\3\6"+
		"\3\6\3\6\3\7\3\7\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\b\3\t\3\t\3\t\3\t\3\t\3"+
		"\n\3\n\3\n\3\n\3\n\3\13\3\13\3\13\3\13\3\13\3\f\3\f\3\f\3\f\3\f\3\r\3"+
		"\r\3\r\3\r\3\r\3\16\3\16\3\16\3\16\3\16\3\17\3\17\3\17\3\17\3\17\3\20"+
		"\3\20\3\20\3\20\3\20\3\21\3\21\3\22\3\22\3\23\3\23\3\23\3\23\3\23\3\24"+
		"\3\24\3\24\3\24\3\24\3\25\3\25\3\25\3\25\3\25\3\26\3\26\3\27\3\27\3\27"+
		"\3\30\3\30\3\31\3\31\3\31\3\31\7\31\u00bb\n\31\f\31\16\31\u00be\13\31"+
		"\3\31\3\31\3\32\3\32\3\32\3\32\7\32\u00c6\n\32\f\32\16\32\u00c9\13\32"+
		"\3\32\3\32\3\33\3\33\3\34\5\34\u00d0\n\34\3\34\7\34\u00d3\n\34\f\34\16"+
		"\34\u00d6\13\34\3\34\5\34\u00d9\n\34\3\34\6\34\u00dc\n\34\r\34\16\34\u00dd"+
		"\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\35\5\35\u00e9\n\35\3\36\3\36"+
		"\3\36\3\36\3\36\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37"+
		"\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37"+
		"\3\37\3\37\5\37\u010b\n\37\3 \3 \3 \3 \3 \5 \u0112\n \3!\6!\u0115\n!\r"+
		"!\16!\u0116\3\"\3\"\3#\3#\7#\u011d\n#\f#\16#\u0120\13#\3#\3#\7#\u0124"+
		"\n#\f#\16#\u0127\13#\5#\u0129\n#\3$\3$\3%\3%\3%\3%\3%\5%\u0132\n%\3&\3"+
		"&\3&\3&\6&\u0138\n&\r&\16&\u0139\3&\3&\3\'\3\'\3(\3(\3)\3)\3*\3*\3*\3"+
		"*\5\u00bc\u00c7\u0139\2+\5\3\7\4\t\5\13\6\r\7\17\b\21\t\23\n\25\13\27"+
		"\f\31\r\33\16\35\17\37\20!\21#\22%\23\'\24)\25+\26-\27/\30\61\31\63\32"+
		"\65\33\67\349\35;\36=\37? A!C\2E\2G\2I\2K\2M\2O\2Q\"S#U$\5\2\3\4\b\5\2"+
		"\13\f\17\17\"\"\3\2\62;\b\2&&))/<C\\aac|\f\2\3\n\r\16\20 &&<<B\\aac|\u00c2"+
		"\u0101\u0412\u0451\3\2__\3\2\60;\2\u0157\2\5\3\2\2\2\2\7\3\2\2\2\2\t\3"+
		"\2\2\2\2\13\3\2\2\2\2\r\3\2\2\2\2\17\3\2\2\2\2\21\3\2\2\2\2\23\3\2\2\2"+
		"\2\25\3\2\2\2\2\27\3\2\2\2\2\31\3\2\2\2\2\33\3\2\2\2\2\35\3\2\2\2\2\37"+
		"\3\2\2\2\3!\3\2\2\2\3#\3\2\2\2\3%\3\2\2\2\4\'\3\2\2\2\4)\3\2\2\2\4+\3"+
		"\2\2\2\4-\3\2\2\2\4/\3\2\2\2\4\61\3\2\2\2\4\63\3\2\2\2\4\65\3\2\2\2\4"+
		"\67\3\2\2\2\49\3\2\2\2\4;\3\2\2\2\4=\3\2\2\2\4?\3\2\2\2\4A\3\2\2\2\4Q"+
		"\3\2\2\2\4S\3\2\2\2\4U\3\2\2\2\5W\3\2\2\2\7Z\3\2\2\2\t]\3\2\2\2\13`\3"+
		"\2\2\2\re\3\2\2\2\17j\3\2\2\2\21o\3\2\2\2\23t\3\2\2\2\25y\3\2\2\2\27~"+
		"\3\2\2\2\31\u0083\3\2\2\2\33\u0088\3\2\2\2\35\u008d\3\2\2\2\37\u0092\3"+
		"\2\2\2!\u0097\3\2\2\2#\u009c\3\2\2\2%\u009e\3\2\2\2\'\u00a0\3\2\2\2)\u00a5"+
		"\3\2\2\2+\u00aa\3\2\2\2-\u00af\3\2\2\2/\u00b1\3\2\2\2\61\u00b4\3\2\2\2"+
		"\63\u00b6\3\2\2\2\65\u00c1\3\2\2\2\67\u00cc\3\2\2\29\u00cf\3\2\2\2;\u00e8"+
		"\3\2\2\2=\u00ea\3\2\2\2?\u010a\3\2\2\2A\u0111\3\2\2\2C\u0114\3\2\2\2E"+
		"\u0118\3\2\2\2G\u0128\3\2\2\2I\u012a\3\2\2\2K\u0131\3\2\2\2M\u0133\3\2"+
		"\2\2O\u013d\3\2\2\2Q\u013f\3\2\2\2S\u0141\3\2\2\2U\u0143\3\2\2\2WX\6\2"+
		"\2\2XY\13\2\2\2Y\6\3\2\2\2Z[\6\3\3\2[\\\13\2\2\2\\\b\3\2\2\2]^\6\4\4\2"+
		"^_\13\2\2\2_\n\3\2\2\2`a\6\5\5\2ab\13\2\2\2bc\3\2\2\2cd\b\5\2\2d\f\3\2"+
		"\2\2ef\6\6\6\2fg\13\2\2\2gh\3\2\2\2hi\b\6\2\2i\16\3\2\2\2jk\6\7\7\2kl"+
		"\13\2\2\2lm\3\2\2\2mn\b\7\2\2n\20\3\2\2\2op\6\b\b\2pq\13\2\2\2qr\3\2\2"+
		"\2rs\b\b\2\2s\22\3\2\2\2tu\6\t\t\2uv\13\2\2\2vw\3\2\2\2wx\b\t\2\2x\24"+
		"\3\2\2\2yz\6\n\n\2z{\13\2\2\2{|\3\2\2\2|}\b\n\2\2}\26\3\2\2\2~\177\6\13"+
		"\13\2\177\u0080\13\2\2\2\u0080\u0081\3\2\2\2\u0081\u0082\b\13\2\2\u0082"+
		"\30\3\2\2\2\u0083\u0084\6\f\f\2\u0084\u0085\13\2\2\2\u0085\u0086\3\2\2"+
		"\2\u0086\u0087\b\f\3\2\u0087\32\3\2\2\2\u0088\u0089\6\r\r\2\u0089\u008a"+
		"\13\2\2\2\u008a\u008b\3\2\2\2\u008b\u008c\b\r\2\2\u008c\34\3\2\2\2\u008d"+
		"\u008e\6\16\16\2\u008e\u008f\13\2\2\2\u008f\u0090\3\2\2\2\u0090\u0091"+
		"\b\16\2\2\u0091\36\3\2\2\2\u0092\u0093\6\17\17\2\u0093\u0094\13\2\2\2"+
		"\u0094\u0095\3\2\2\2\u0095\u0096\b\17\2\2\u0096 \3\2\2\2\u0097\u0098\6"+
		"\20\20\2\u0098\u0099\13\2\2\2\u0099\u009a\3\2\2\2\u009a\u009b\b\20\4\2"+
		"\u009b\"\3\2\2\2\u009c\u009d\t\2\2\2\u009d$\3\2\2\2\u009e\u009f\13\2\2"+
		"\2\u009f&\3\2\2\2\u00a0\u00a1\6\23\21\2\u00a1\u00a2\13\2\2\2\u00a2\u00a3"+
		"\3\2\2\2\u00a3\u00a4\b\23\4\2\u00a4(\3\2\2\2\u00a5\u00a6\6\24\22\2\u00a6"+
		"\u00a7\13\2\2\2\u00a7\u00a8\3\2\2\2\u00a8\u00a9\b\24\4\2\u00a9*\3\2\2"+
		"\2\u00aa\u00ab\6\25\23\2\u00ab\u00ac\13\2\2\2\u00ac\u00ad\3\2\2\2\u00ad"+
		"\u00ae\b\25\5\2\u00ae,\3\2\2\2\u00af\u00b0\7,\2\2\u00b0.\3\2\2\2\u00b1"+
		"\u00b2\7c\2\2\u00b2\u00b3\7u\2\2\u00b3\60\3\2\2\2\u00b4\u00b5\7~\2\2\u00b5"+
		"\62\3\2\2\2\u00b6\u00bc\7$\2\2\u00b7\u00b8\7^\2\2\u00b8\u00bb\7$\2\2\u00b9"+
		"\u00bb\13\2\2\2\u00ba\u00b7\3\2\2\2\u00ba\u00b9\3\2\2\2\u00bb\u00be\3"+
		"\2\2\2\u00bc\u00bd\3\2\2\2\u00bc\u00ba\3\2\2\2\u00bd\u00bf\3\2\2\2\u00be"+
		"\u00bc\3\2\2\2\u00bf\u00c0\7$\2\2\u00c0\64\3\2\2\2\u00c1\u00c7\7)\2\2"+
		"\u00c2\u00c3\7^\2\2\u00c3\u00c6\7)\2\2\u00c4\u00c6\13\2\2\2\u00c5\u00c2"+
		"\3\2\2\2\u00c5\u00c4\3\2\2\2\u00c6\u00c9\3\2\2\2\u00c7\u00c8\3\2\2\2\u00c7"+
		"\u00c5\3\2\2\2\u00c8\u00ca\3\2\2\2\u00c9\u00c7\3\2\2\2\u00ca\u00cb\7)"+
		"\2\2\u00cb\66\3\2\2\2\u00cc\u00cd\7?\2\2\u00cd8\3\2\2\2\u00ce\u00d0\7"+
		"/\2\2\u00cf\u00ce\3\2\2\2\u00cf\u00d0\3\2\2\2\u00d0\u00d4\3\2\2\2\u00d1"+
		"\u00d3\t\3\2\2\u00d2\u00d1\3\2\2\2\u00d3\u00d6\3\2\2\2\u00d4\u00d2\3\2"+
		"\2\2\u00d4\u00d5\3\2\2\2\u00d5\u00d8\3\2\2\2\u00d6\u00d4\3\2\2\2\u00d7"+
		"\u00d9\7\60\2\2\u00d8\u00d7\3\2\2\2\u00d8\u00d9\3\2\2\2\u00d9\u00db\3"+
		"\2\2\2\u00da\u00dc\t\3\2\2\u00db\u00da\3\2\2\2\u00dc\u00dd\3\2\2\2\u00dd"+
		"\u00db\3\2\2\2\u00dd\u00de\3\2\2\2\u00de:\3\2\2\2\u00df\u00e0\7v\2\2\u00e0"+
		"\u00e1\7t\2\2\u00e1\u00e2\7w\2\2\u00e2\u00e9\7g\2\2\u00e3\u00e4\7h\2\2"+
		"\u00e4\u00e5\7c\2\2\u00e5\u00e6\7n\2\2\u00e6\u00e7\7u\2\2\u00e7\u00e9"+
		"\7g\2\2\u00e8\u00df\3\2\2\2\u00e8\u00e3\3\2\2\2\u00e9<\3\2\2\2\u00ea\u00eb"+
		"\7g\2\2\u00eb\u00ec\7n\2\2\u00ec\u00ed\7u\2\2\u00ed\u00ee\7g\2\2\u00ee"+
		">\3\2\2\2\u00ef\u00f0\7\60\2\2\u00f0\u00f1\7\60\2\2\u00f1\u00f2\7\61\2"+
		"\2\u00f2\u00f3\3\2\2\2\u00f3\u010b\5?\37\2\u00f4\u00f5\7\60\2\2\u00f5"+
		"\u010b\7\60\2\2\u00f6\u00f7\7\60\2\2\u00f7\u00f8\7\61\2\2\u00f8\u00f9"+
		"\3\2\2\2\u00f9\u010b\5?\37\2\u00fa\u010b\7\60\2\2\u00fb\u00fc\7]\2\2\u00fc"+
		"\u00fd\5G#\2\u00fd\u00fe\7_\2\2\u00fe\u00ff\5E\"\2\u00ff\u0100\5?\37\2"+
		"\u0100\u010b\3\2\2\2\u0101\u0102\7]\2\2\u0102\u0103\5G#\2\u0103\u0104"+
		"\7_\2\2\u0104\u010b\3\2\2\2\u0105\u0106\5G#\2\u0106\u0107\5E\"\2\u0107"+
		"\u0108\5?\37\2\u0108\u010b\3\2\2\2\u0109\u010b\5G#\2\u010a\u00ef\3\2\2"+
		"\2\u010a\u00f4\3\2\2\2\u010a\u00f6\3\2\2\2\u010a\u00fa\3\2\2\2\u010a\u00fb"+
		"\3\2\2\2\u010a\u0101\3\2\2\2\u010a\u0105\3\2\2\2\u010a\u0109\3\2\2\2\u010b"+
		"@\3\2\2\2\u010c\u010d\7]\2\2\u010d\u010e\5C!\2\u010e\u010f\7_\2\2\u010f"+
		"\u0112\3\2\2\2\u0110\u0112\5C!\2\u0111\u010c\3\2\2\2\u0111\u0110\3\2\2"+
		"\2\u0112B\3\2\2\2\u0113\u0115\t\4\2\2\u0114\u0113\3\2\2\2\u0115\u0116"+
		"\3\2\2\2\u0116\u0114\3\2\2\2\u0116\u0117\3\2\2\2\u0117D\3\2\2\2\u0118"+
		"\u0119\4/\61\2\u0119F\3\2\2\2\u011a\u011e\5I$\2\u011b\u011d\5K%\2\u011c"+
		"\u011b\3\2\2\2\u011d\u0120\3\2\2\2\u011e\u011c\3\2\2\2\u011e\u011f\3\2"+
		"\2\2\u011f\u0129\3\2\2\2\u0120\u011e\3\2\2\2\u0121\u0125\5M&\2\u0122\u0124"+
		"\5K%\2\u0123\u0122\3\2\2\2\u0124\u0127\3\2\2\2\u0125\u0123\3\2\2\2\u0125"+
		"\u0126\3\2\2\2\u0126\u0129\3\2\2\2\u0127\u0125\3\2\2\2\u0128\u011a\3\2"+
		"\2\2\u0128\u0121\3\2\2\2\u0129H\3\2\2\2\u012a\u012b\t\5\2\2\u012bJ\3\2"+
		"\2\2\u012c\u012d\7\60\2\2\u012d\u0132\5M&\2\u012e\u0132\5I$\2\u012f\u0132"+
		"\5O\'\2\u0130\u0132\7/\2\2\u0131\u012c\3\2\2\2\u0131\u012e\3\2\2\2\u0131"+
		"\u012f\3\2\2\2\u0131\u0130\3\2\2\2\u0132L\3\2\2\2\u0133\u0137\7]\2\2\u0134"+
		"\u0135\7^\2\2\u0135\u0138\7_\2\2\u0136\u0138\n\6\2\2\u0137\u0134\3\2\2"+
		"\2\u0137\u0136\3\2\2\2\u0138\u0139\3\2\2\2\u0139\u013a\3\2\2\2\u0139\u0137"+
		"\3\2\2\2\u013a\u013b\3\2\2\2\u013b\u013c\7_\2\2\u013cN\3\2\2\2\u013d\u013e"+
		"\t\7\2\2\u013eP\3\2\2\2\u013f\u0140\7*\2\2\u0140R\3\2\2\2\u0141\u0142"+
		"\7+\2\2\u0142T\3\2\2\2\u0143\u0144\t\2\2\2\u0144\u0145\3\2\2\2\u0145\u0146"+
		"\b*\6\2\u0146V\3\2\2\2\27\2\3\4\u00ba\u00bc\u00c5\u00c7\u00cf\u00d4\u00d8"+
		"\u00dd\u00e8\u010a\u0111\u0116\u011e\u0125\u0128\u0131\u0137\u0139\7\7"+
		"\4\2\7\3\2\6\2\2\4\2\2\b\2\2";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}