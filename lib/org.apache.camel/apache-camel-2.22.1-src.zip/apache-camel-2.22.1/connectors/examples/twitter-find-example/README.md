## Twitter Find Example

This example searches for some keywords

This is an example that uses the `twitter-find` Camel connectors. These connectors
are used as if they are regular Camel components in Camel routes.

### How to run

This example can be run from the command line using:

    mvn spring-boot:run
    
### Configuring Credentials

The example uses the `@CamelTweet` twitter account for connecting to twitter.

You can configure your own accounts in the `application.properties` file.
