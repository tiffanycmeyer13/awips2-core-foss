## Wine Connector

A Camel connector that is based on the `beverage-component`.

This connector is a very basic connector with only a few options.

