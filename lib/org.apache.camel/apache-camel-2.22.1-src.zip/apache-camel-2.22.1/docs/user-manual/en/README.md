![Apache Camel Logo](images/camel-logo.png)

Apache Camel User Manual
====================

The User manual is an in depth manual on all aspects of Apache Camel

