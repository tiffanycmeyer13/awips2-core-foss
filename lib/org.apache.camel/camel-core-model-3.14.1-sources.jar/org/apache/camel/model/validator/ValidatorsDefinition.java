/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.camel.model.validator;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.camel.spi.Metadata;

/**
 * To configure validators.
 */
@Metadata(label = "validation", title = "Validations")
@XmlRootElement(name = "validators")
@XmlAccessorType(XmlAccessType.FIELD)
public class ValidatorsDefinition {

    @XmlElements({
            @XmlElement(required = false, name = "endpointValidator", type = EndpointValidatorDefinition.class),
            @XmlElement(required = false, name = "predicateValidator", type = PredicateValidatorDefinition.class),
            @XmlElement(required = false, name = "customValidator", type = CustomValidatorDefinition.class) })
    private List<ValidatorDefinition> validators;

    /**
     * The configured transformers
     */
    public void setValidators(List<ValidatorDefinition> validators) {
        this.validators = validators;
    }

    public List<ValidatorDefinition> getValidators() {
        return validators;
    }

}
