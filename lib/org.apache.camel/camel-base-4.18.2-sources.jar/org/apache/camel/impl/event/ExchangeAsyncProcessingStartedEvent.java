/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.camel.impl.event;

import java.io.Serial;

import org.apache.camel.Exchange;
import org.apache.camel.Route;
import org.apache.camel.spi.CamelEvent;
import org.apache.camel.support.RoutePolicySupport;

/**
 * Notifies that async processing has started. It's guaranteed to run on the same thread on which
 * {@link RoutePolicySupport#onExchangeBegin(Route, Exchange)} was called and/or {@link ExchangeSendingEvent} was fired.
 *
 * Special event only in use for camel-tracing / camel-opentelemetry. This event is NOT (by default) in use.
 *
 * @see ExchangeAsyncProcessingStartedEvent
 */
public class ExchangeAsyncProcessingStartedEvent extends AbstractExchangeEvent
        implements CamelEvent.ExchangeAsyncProcessingStartedEvent {
    private static final @Serial long serialVersionUID = -19248832613958122L;

    public ExchangeAsyncProcessingStartedEvent(Exchange source) {
        super(source);
    }

    @Override
    public final String toString() {
        return getExchange().getExchangeId();
    }
}
