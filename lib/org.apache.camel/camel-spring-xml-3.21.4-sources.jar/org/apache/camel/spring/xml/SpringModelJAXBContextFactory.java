/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.camel.spring.xml;

import org.apache.camel.spi.ModelJAXBContextFactory;
import org.apache.camel.spi.annotations.JdkService;
import org.apache.camel.xml.jaxb.DefaultModelJAXBContextFactory;

@JdkService(ModelJAXBContextFactory.FACTORY + "-spring")
public class SpringModelJAXBContextFactory extends DefaultModelJAXBContextFactory {

    public static final String ADDITIONAL_JAXB_CONTEXT_PACKAGES = ":"
                                                                  + "org.apache.camel.core.xml:"
                                                                  + "org.apache.camel.spring.xml:";

    @Override
    protected String getPackages() {
        return super.getPackages() + ADDITIONAL_JAXB_CONTEXT_PACKAGES;
    }
}
