Camel Component Project
=======================

This project is a template of a Camel component using Scala.

To build this project use

    mvn install

For more help see the Apache Camel documentation:

    http://camel.apache.org/writing-components.html


Notice:

We favor writing Camel components in plain Java, which allows all people to consume and use the components easily.
Writing components in Scala is intended in situations when being used together with other Scala libraries such as Akka, Play, etc.

See discussion at:

    http://camel.465427.n5.nabble.com/Create-a-new-Camel-component-via-Scala-Component-Archetype-td5708543.html#a5711675

