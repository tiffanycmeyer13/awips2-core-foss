Camel Data Format Project
=========================

This project is a template of a Camel data format.

To build this project use

    mvn install

For more help see the Apache Camel documentation:

    http://camel.apache.org/writing-components.html
    
