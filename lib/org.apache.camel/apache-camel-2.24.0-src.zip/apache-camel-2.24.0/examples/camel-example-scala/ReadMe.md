# Camel Router with Scala Project

A simple example that uses Scala programming language to define a little Camel route.

The Camel route triggers every 5th second and logs a message to the console

### How to run

To build this project use

    mvn install

To run this project

    mvn exec:java
    
### Forum, Help, etc

If you hit an problems please let us know on the Camel Forums
	<http://camel.apache.org/discussion-forums.html>

Please help us make Apache Camel better - we appreciate any feedback you may
have.  Enjoy!


The Camel riders!