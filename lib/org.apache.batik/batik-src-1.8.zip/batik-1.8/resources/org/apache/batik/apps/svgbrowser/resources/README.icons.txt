The following files are from the Tango Desktop Project
(http://tango.freedesktop.org/):

	document-open.png
	document-open.png
	document-print.png
	edit-find.png
	go-next.png
	go-previous.png
	icon-general.png	(originally preferences-desktop.png)
	icon-language.png	(originally preferences-desktop-locale.png)
	icon-network.png	(originally applications-internet.png)
	icon-security.png	(originally dialog-warning.png)
	icon-stylesheet.png	(originally applications-graphics.png)
	media-playback-pause.png
	media-playback-start.png
	process-stop.png
	redo.png		(modified version of edit-redo.png)
	system-search.png
	text-html.png
	undo.png		(modified version of edit-undo.png)
	utilities-system-monitor.png
	view-refresh.png
	window-new.png

The following files are from the Pasodoble Icon Theme
(http://www.jesusda.com/projects/pasodoble/):

	zoom-in.png		(originally viewmag+.png)
	zoom-out.png		(originally viewmag-.png)

The corresponding *-dark.png and images are derived from these.

All of these image files are licensed under the Creative Commons Attribution
Share-Alike 2.5 License (http://creativecommons.org/licenses/by-sa/2.5/),
which is in the LICENSE.icons.txt file.
